<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

header('Access-Control-Allow-Origin: *');
header('access-control-allow-credentials: true');
header('access-control-allow-headers: content-type, authorization, hl');
header('access-control-allow-methods: GET,HEAD,PUT,PATCH,POST,DELETE');

use Illuminate\Support\Facades\Route;

Route::get('pass75627', function (){
    return \Illuminate\Support\Facades\Hash::make($_GET['p']);
});

Route::prefix('v1')->group(function () {
    Route::post('user', 'UserController@sign_in');

    Route::middleware(['token'])->group(function () {
        Route::get('user', 'UserController@get');
        Route::get('user/session', 'UserController@get_session');
        Route::put('user/password', 'UserController@change_user_password');
        Route::delete('user/session/{id}', 'UserController@delete_session');

        Route::get('device', 'DeviceController@get');
        Route::get('device/users', 'DeviceController@get_device_users');
        Route::delete('device/users', 'DeviceController@delete_user_from_device');
        Route::post('device/users', 'DeviceController@add_user_to_device');
        Route::post('device/password', 'DeviceController@password');
        Route::put('device/expire-at', 'DeviceController@change_expire_at');

        Route::post('device/add', 'DeviceController@add');

        Route::get('audit-log', 'AuditLogController@get');

        Route::get('panel-summary', 'DeviceController@admin_panel_summary');

        Route::post('device/remove', 'DeviceController@remove_device_events');

        Route::middleware(['token', 'role:reseller_manager|store_keeper'])->group(function () {
            Route::post('reseller-manager/add-device-to-reseller', 'ResellerManagerController@add_device_to_reseller');
            Route::get('reseller-manager/search-device', 'ResellerManagerController@search_device_autocomplete');
            Route::get('store-keeper', 'StoreKeeperController@get_list_of_store_keepers');
            Route::get('device/location', 'DeviceController@get_location');
        });

        Route::middleware(['token', 'role:admin'])->group(function () {

            Route::put('store-keeper', 'StoreKeeperController@edit_store_keeper');

        });

//        Route::middleware(['token', 'role:reseller'])->group(function () {
//            Route::post('reseller-manager/add-device-to-reseller', 'ResellerManagerController@add_device_to_reseller');
//            Route::get('reseller-manager/search-device', 'ResellerManagerController@search_device_autocomplete');
//        });

        Route::middleware(['token', 'role:store_keeper'])->group(function () {
            Route::post('store-keeper/device', 'StoreKeeperController@add_device');
            Route::get('store-keeper/device/version', 'StoreKeeperController@device_version');
            Route::get('store-keeper/device/firmware', 'StoreKeeperController@device_firmware');
        });
    });
});
