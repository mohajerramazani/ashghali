<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Validator;
use App\Rules\TokenValidator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Role
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @param $role Role of the user
     * @return mixed
     */
    public function handle($request, Closure $next, $role)
    {
        if (Auth::guest()) {
            return response()->json([
                'status' => 'WRONG_CREDENTIALS',
                'message' => __('Token is invalid or it\'s expired.'),
            ], 401);
        }

        // Maybe our role is array
        $role = explode('|', $role);

        if (!in_array(Auth::user()->role, $role)) {
            return response()->json([
                'status' => 'ACCESS_DENIED',
                'errors' => __('You don\'t have permission to use this API.'),
            ], 401);
        }

        return $next($request);
    }
}
