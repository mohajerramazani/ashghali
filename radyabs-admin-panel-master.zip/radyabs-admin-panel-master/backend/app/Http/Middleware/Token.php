<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Rules\TokenValidator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Token
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $token = explode(' ', $request->header('Authorization'));

        if (count($token) === 2 && $token[0] === 'Bearer') {
            $token = $token[1];
        } else {
            $token = null;
        }

        $validator = Validator::make(['token' => $token], [
            'token' => ['required', new TokenValidator]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'WRONG_CREDENTIALS',
                'message' => __('Token is invalid or it\'s expired.'),
            ], 401);
        }

        // Split the token and separate user id from actual token
        $token = explode('H', $token);

        // Check if token is valid (get user id)
        $user = DB::table('reseller_tokens')
            ->where('reseller_user_id', hexdec($token[0]))
            ->where('token', md5(md5($token[1])))
            ->exists();

        if (!$user) {
            return response()->json([
                'status' => 'WRONG_CREDENTIALS',
                'message' => __('Token is invalid or it\'s expired.'),
            ], 401);
        }

        // Authorise the user
        Auth::onceUsingId(hexdec($token[0]));

        return $next($request);
    }
}
