<?php

namespace App\Http\Controllers;

use App\Libs\Functions;
use App\Libs\ResellerAuditLogs;
use App\Rules\base64image;
use App\Rules\phone;
use Carbon\Carbon;
use Exception;
use http\Env\Response;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class StoreKeeperController extends Controller
{
    public function device_version(Request $request)
    {
        return response()->json([
            'status' => 'OK',
            'data' => DB::table('device_versions')->get()
        ]);
    }

    public function device_firmware(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_version_id' => 'required|numeric|exists:device_versions,id'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        return response()->json([
            'status' => 'OK',
            'data' => DB::table('device_firmwares')
                ->select('id', 'firmware_name as name')
                ->where('device_version_id', $request->input('device_version_id'))
                ->get()
        ]);
    }

    public function add_device(Request $request)
    {
        $starttime = microtime(true);

        $validator = Validator::make($request->all(), [
            'device' => 'required|array|min:1|max:1024',
            'device_firmware_id' => 'required|numeric|exists:device_firmwares,id',
            'built_at' => 'required|date_format:Y-m-d H:i:s',
            'trial' => 'required|boolean',
            'username' => [
                'nullable',
                'string',
                'max:32',
                Rule::exists('reseller_users')->where(function ($query) {
                    $query->where('role', 'reseller');
                }),
            ]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'device.*' => 'required|numeric|digits:15',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => [
                    'device' => ['فرمت شماره سریال‌های وارد شده معتبر نمی‌باشد.']
                ]
            ], 422);
        }

        // Check if device is not trial
        if (!$request->input('trial')) {
            if (Auth::User()->credits < count($request->input('device')) * 365) {
                return response()->json([
                    'status' => 'NOT_ENOUGH_CREDITS',
                    'message' => 'موجودی حساب شما برای اضافه کردن ' . Functions::english2Persian_number(count($request->input('device'))) . ' کافی نمی‌باشد. شما اجازه اضافه‌کردن ' . Functions::english2Persian_number(round(Auth::User()->credits / 365)) . ' دستگاه را دارید.'
                ], 403);
            }
        }

        $successfully_added_devices = 0;
        $new_credits = 0;

        $reseller_user = null;
        if ($request->input('username')) {
            $reseller_user = DB::table('reseller_users')->select('id', 'name')->where('username', $request->input('username'))->first();
        }

        foreach ($request->input('device') as $device_id) {
            try {
                if ($reseller_user) {
                    $insert = DB::table('devices')
                        ->insert([
                            'id' => $device_id,
                            'creator_reseller_user_id' => Auth::id(),
                            'device_firmware_id' => $request->input('device_firmware_id'),
                            'initial_credits' => $request->input('trial') ? 3 : 365,
                            'trial' => $request->input('trial'),
                            'reseller_user_id' => $reseller_user->id,
                            'agent_reseller_user_id' => Auth::id(),
                            'date_created' => date("Y-m-d H:i:s"),
                            'updated_at' => date("Y-m-d H:i:s"),
                            'built_at' => $request->input('built_at')
                        ]);
                } else {
                    $insert = DB::table('devices')
                        ->insert([
                            'id' => $device_id,
                            'creator_reseller_user_id' => Auth::id(),
                            'device_firmware_id' => $request->input('device_firmware_id'),
                            'initial_credits' => $request->input('trial') ? 3 : 365,
                            'trial' => $request->input('trial'),
                            'date_created' => date("Y-m-d H:i:s"),
                            'updated_at' => date("Y-m-d H:i:s"),
                            'built_at' => $request->input('built_at')
                        ]);
                }


                if ($insert) {
                    if ($request->input('trial')) {
                        $log_name = 'WAREHOUSE_ADD_TRIAL_DEVICE';
                    } else {
                        $log_name = 'WAREHOUSE_ADD_DEVICE';
                    }
                    $successfully_added_devices++;
                    $new_credits += 365;
                    ResellerAuditLogs::save($log_name, [$device_id]);
                    if ($reseller_user) {
                        ResellerAuditLogs::save('RESELLER_MANAGER_ADD_DEVICE_TO_RESELLER', [$device_id, $reseller_user->id, $reseller_user->name]);
                    }
                }
            } catch (QueryException $e) {
            }
        }

        // Change warehouse credits if device is not trial
        if (!$request->input('trial')) {
            DB::table('reseller_users')
                ->where('id', Auth::id())
                ->decrement('credits', $new_credits);
        }

        $diff = microtime(true) - $starttime;

        // Process final message
        if (count($request->input('device')) == $successfully_added_devices) {
            $response_message = 'همه دستگاه‌ها با موفقیت به سیستم اضافه شدند.';
        } elseif ($successfully_added_devices === 0) {
            $response_message = 'هیچ دستگاهی به سیستم اضافه نشد.';
        } else {
            $response_message = 'از مجموع ' . Functions::english2Persian_number(count($request->input('device'))) . ' دستگاه، ' . Functions::english2Persian_number($successfully_added_devices) . ' دستگاه با موفیت به سیستم اضافه شدند.';
        }

        return response()->json([
            'status' => 'OK',
            'message' => $response_message,
            'time' => strftime('%T', mktime(0, 0, intval($diff))) . str_replace('0.', '.', sprintf('%.3f', $diff - intval($diff)))
        ], $successfully_added_devices === 0 ? 400 : 200);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function get_list_of_store_keepers(Request $request): JsonResponse
    {
        $resellers = DB::table('reseller_users')
            ->select('id', 'name', 'username', 'role', 'credits', 'created_at', 'updated_at')
            ->where('role', 'store_keeper')
            ->get();

        return response()->json([
            'status' => 'OK',
            'data' => $resellers
        ]);
    }

    /**
    * @param Request $request
    * @return JsonResponse
    */
    public function edit_store_keeper(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'id' => [
                'required',
                'numeric',
                Rule::exists('reseller_users')->where(function ($query) {
                    $query->where('role', 'store_keeper');
                })],
            'credits' => 'required|numeric|min:-999999|max:999999'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $old = $resellers = DB::table('reseller_users')
            ->where('id', $request->input('id'))
            ->first();

        DB::table('reseller_users')
            ->where('id', $request->input('id'))
            ->update([
                'credits' => $request->input('credits'),
                'updated_at' => now(),
            ]);

        ResellerAuditLogs::save('EDIT_CREDITS', [$old->name, $old->credits, $request->input('credits')]);

        return response()->json([
            'status' => 'OK'
        ]);
    }
}
