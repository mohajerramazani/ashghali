<?php

namespace App\Http\Controllers;

use App\Libs\Functions;
use App\Libs\ResellerAuditLogs;
use App\Rules\base64image;
use App\Rules\phone;
use Exception;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ResellerManagerController extends Controller
{
    public function add_device_to_reseller(Request $request)
    {
        $starttime = microtime(true);

        $validator = Validator::make($request->all(), [
            'device' => 'required|array|min:1|max:1024',
            'username' => [
                'required',
                'string',
                'max:32',
                Rule::exists('reseller_users')->where(function ($query) {
                    $query->where('role', 'reseller');
                }),
            ]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'device.*' => 'required|numeric|digits:15',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => [
                    'device' => ['فرمت شماره سریال‌های وارد شده معتبر نمی‌باشد.']
                ]
            ], 422);
        }

        $user = DB::table('reseller_users')->where('username', $request->input('username'))->first();

        $successfully_added_devices = 0;
        foreach ($request->input('device') as $device_id) {
            $update = DB::table('devices')
                ->where('id', $device_id)
                ->whereNull('reseller_user_id')
                ->update([
                    'reseller_user_id' => $user->id,
                    'updated_at' => date("Y-m-d H:i:s"),
                    'agent_reseller_user_id' => Auth::id()
                ]);
            if ($update) {
                $successfully_added_devices++;
                ResellerAuditLogs::save('RESELLER_MANAGER_ADD_DEVICE_TO_RESELLER', [$device_id, $user->id, $user->name]);
            }
        }

        $diff = microtime(true) - $starttime;

        return response()->json([
            'status' => 'OK',
            'message' => count($request->input('device')) == $successfully_added_devices ? ('همه دستگاه‌ها با موفقیت به «' . $user->name . '» اضافه شدند.') : ('از مجموع ' . Functions::english2Persian_number(count($request->input('device'))) . ' دستگاه، ' . Functions::english2Persian_number($successfully_added_devices) . ' دستگاه با موفیت به حساب «' . $user->name . '» اضافه شد.'),
            'time' => strftime('%T', mktime(0, 0, intval($diff))) . str_replace('0.', '.', sprintf('%.3f', $diff - intval($diff)))
        ]);
    }


    public function search_device_autocomplete(Request $request)
    {
        $starttime = microtime(true);

        $validator = Validator::make($request->all(), [
            'device' => 'nullable|string|max:32',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $objects = DB::table('devices')
            ->select('id as device_id')
            ->where('id', 'like', '%' . $request->input('device') . '%')
            ->whereNull('reseller_user_id');
        if (Auth::User()->role == 'store_keeper') {
            $objects = $objects->where('creator_reseller_user_id', Auth::id());
        }
        $objects = $objects->limit(10)
            ->get()
            ->pluck('device_id');

        ResellerAuditLogs::save('RESELLER_MANAGER_DEVICE_SEARCH', [$request->input('device')]);

        $diff = microtime(true) - $starttime;

        return response()->json([
            'status' => 'OK',
            'data' => $objects,
            'time' => strftime('%T', mktime(0, 0, intval($diff))) . str_replace('0.', '.', sprintf('%.3f', $diff - intval($diff)))
        ]);
    }
}
