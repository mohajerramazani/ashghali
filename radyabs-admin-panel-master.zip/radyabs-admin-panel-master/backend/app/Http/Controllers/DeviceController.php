<?php

namespace App\Http\Controllers;

use App\Libs\Functions;
use App\Libs\ResellerAuditLogs;
use App\Rules\base64image;
use App\Rules\phone;
use Exception;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class DeviceController extends Controller
{
    public function get(Request $request)
    {
        $starttime = microtime(true);

        ResellerAuditLogs::save('LIST_OF_DEVICES');

        if (Auth::User()->role == 'store_keeper') {
            $objects = DB::table('devices')
                ->select('devices.id as device_id', 'firmware_name as version', 'date_created as created_at', 'device_versions.name as version_name', 'expire_at')
                ->leftJoin('device_firmwares', 'device_firmwares.id', 'devices.device_firmware_id')
                ->leftJoin('device_versions', 'device_versions.id', 'device_firmwares.device_version_id')
                ->where('creator_reseller_user_id', Auth::id())
                ->get();
        } elseif (Auth::User()->role == 'admin') {
            $objects = DB::table('devices')
                ->select('devices.id as device_id', 'firmware_name as version', 'date_created as created_at', 'device_versions.name as version_name', 'expire_at')
                ->leftJoin('device_firmwares', 'device_firmwares.id', 'devices.device_firmware_id')
                ->leftJoin('device_versions', 'device_versions.id', 'device_firmwares.device_version_id')
                ->get();
        } else {
            $objects = DB::table('devices')
                ->select('devices.id as device_id', 'firmware_name as version', 'date_created as created_at', 'device_versions.name as version_name', 'expire_at')
                ->leftJoin('device_firmwares', 'device_firmwares.id', 'devices.device_firmware_id')
                ->leftJoin('device_versions', 'device_versions.id', 'device_firmwares.device_version_id')
                ->where('reseller_user_id', Auth::id())
                ->get();
        }

        $last_event = DB::table('events')
            ->selectRaw('device_id, max(device_date_time) as insert_date_time')
            ->whereIn('device_id', $objects->pluck('device_id'))
            ->groupBy('device_id')
            ->get();

        $last_event_keyed = $last_event->mapWithKeys(function ($item) {
            return [$item->device_id => $item->insert_date_time];
        });

        $result = [];
        foreach ($objects as $object) {
            $result[] = [
                'device_id' => (int)$object->device_id,
                'version' => $object->version_name . ' (' . $object->version . ')',
                'expire_at' => $object->expire_at,
                'created_at' => $object->created_at,
                'last_event' => $last_event_keyed[$object->device_id] ?? null
            ];
        }

        $diff = microtime(true) - $starttime;

        return response()->json([
            'status' => 'OK',
            'time' => strftime('%T', mktime(0, 0, intval($diff))) . str_replace('0.', '.', sprintf('%.3f', $diff - intval($diff))),
            'data' => $result
        ]);
    }


    public function admin_panel_summary(Request $request)
    {
        if (Auth::User()->role != 'admin') {
            return response()->json([
                'status' => 'INVALID_DEVICE',
                'message' => 'شما اجازه استفاده از این قابلیت را ندارید.'
            ], 403);
        }

        $result = [];

        // All devices count
        $result[] = [
            'name' => 'تعداد دستگاه‌ها',
            'value' => DB::table('devices')->count() . ' دستگاه',
            'description' => 'تعداد تمام دستگاه‌هایی که در سیستم تا کنون ثبت شده است.'
        ];

        $result[] = [
            'name' => 'دستگاه‌های «آقای سلمانی»',
            'value' => DB::table('devices')
                    ->where('reseller_user_id', 1)
                    ->count() . ' دستگاه',
            'description' => 'تعداد دستگاه‌هایی که «آقای سلمانی» نماینده آن‌ها می‌باشد.'
        ];
        $result[] = [
            'name' => 'دستگاه‌های «مرکز تحقیقات سجاد»',
            'value' => DB::table('devices')
                    ->where('reseller_user_id', 3)
                    ->count() . ' دستگاه',
            'description' => 'تعداد دستگاه‌هایی که «مرکز تحقیقات سجاد» نماینده آن‌ها می‌باشد.'
        ];

        $result[] = [
            'name' => 'دستگاه‌های بدون مالکیت',
            'value' => DB::table('devices')
                    ->whereNull('reseller_user_id')
                    ->count() . ' دستگاه',
            'description' => 'تعداد دستگاه‌هایی که دارای نماینده نمی‌باشند.'
        ];


        // All users count
        $result[] = [
            'name' => 'تعداد کاربران',
            'value' => DB::table('users')->where('verified', true)->count() . ' نفر',
            'description' => 'تعداد تمام کاربرانی که در ردیابز حساب ایجاد کرده و اکانت خود را فعال کرده‌اند.'
        ];

        $result[] = [
            'name' => 'دستگاه‌های فعال در پنج روز گذشته',
            'value' => DB::table(DB::raw('events use index(`For newest_data_on_server`)'))
                    ->select('device_id')
                    ->where('insert_date_time', '>', date("Y-m-d H:i:s", time() - (5 * 24 * 60 * 60)))
                    ->groupBy('device_id')
                    ->get()->count() . ' دستگاه',
            'description' => 'تعداد دستگاه‌هایی که در طی پنج روز گذشته حداقل یک داده به سرور ارسال کرده‌اند.'
        ];

        $result[] = [
            'name' => 'تعداد خرید‌ها برای تمدید دستگاه',
            'value' => DB::table('payments')
                    ->where('status', 'SUCCESSFUL')
                    ->count() . ' عدد',
            'description' => 'تعداد خرید‌های آنلاینی که برای تمدید دستگاه صورت گرفته است.'
        ];

        $result[] = [
            'name' => 'مجموع خرید‌ها برای تمدید دستگاه',
            'value' => DB::table('payments')
                    ->where('status', 'SUCCESSFUL')
                    ->sum('price') . ' تومان',
            'description' => 'مجموع خرید‌های آنلاینی که برای تمدید دستگاه صورت گرفته است.'
        ];

        return response()->json([
            'status' => 'OK',
            'data' => $result
        ]);
    }


    public function password(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        return null;
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ]
        ]);

        if ($request->input('device_id') == '862549042340490') {
            return response()->json([
                'status' => 'INVALID_DEVICE'
            ], 403);
        }

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        ResellerAuditLogs::save('GET_DEVICE_PASSWORD', [$request->input('device_id')]);

        $poly = 0xa001;
        $xor = 0x0000;
        $crc = 0x0;
        $len = strlen($request->input('device_id'));
        $i = 0;
        while ($len--) {
            $crc ^= ord($request->input('device_id')[$i++]) << 8;
            $crc &= 0xffff;
            for ($j = 0; $j < 8; $j++) {
                $crc = ($crc & 0x8000) ? ($crc << 1) ^ $poly : $crc << 1;
                $crc &= 0xffff;
            }
        }
        $crc ^= $xor;

        $crc = dechex($crc);
        $crc = strlen($crc) < 4 ? ('0' . $crc) : $crc;

        $fn = $crc[2] . $crc[3] . $crc[0] . $crc[1];

        $first = ($request->input('device_id')[12] + 1) > 9 ? 0 : ($request->input('device_id')[12] + 1);
        $second = ($request->input('device_id')[14] + 1) > 9 ? 0 : ($request->input('device_id')[14] + 1);

        return response()->json([
            'status' => 'OK',
            'data' => [
                'password' => $fn . $first . $second
            ]
        ]);
    }

    public function add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    $query->where('reseller_user_id', Auth::id());
                }),
            ],
            'user_phone' => ['required', new phone],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        if (!DB::table('devices')->where('id', $request->input('device_id'))->whereNotNull('user_id')->exists()) {
            return response()->json([
                'status' => 'BAD_DEVICE',
                'message' => 'این دستگاه تاکنون به هیچ کاربری اختصاص نیافته است. بعد از ثبت دستگاه برای حداقل یک کاربر (ثبت شماره پلاک و...) می‌توانید این دستگاه را به کاربران دیگر متصل نمایید.'
            ], 400);
        }

        $user = DB::table('users')
            ->where('phone', Functions::format_phone($request->input('user_phone')))
            ->where('verified', true)
            ->first();

        if (!$user) {
            return response()->json([
                'status' => 'USER_NOT_FOUND_ERROR',
                'message' => 'این کاربر موجود نیست. کاربر ابتدا باید در سیستم ثبت‌نام کند.'
            ], 400);
        }

        // Check if user with device ID exists
        if (DB::table('device_owners')
            ->where('user_id', $user->id)
            ->where('device_id', $request->input('device_id'))
            ->exists()) {
            return response()->json([
                'status' => 'DEVICE_EXISTS_FOR_USER',
                'message' => 'این دستگاه قبلا به کاربر «' . $user->name . '» اضافه شده‌است.'
            ], 400);
        }

        DB::table('device_owners')->insert([
            'device_id' => $request->input('device_id'),
            'user_id' => $user->id,
            'reseller_id' => Auth::id(),
        ]);

        return response()->json([
            'status' => 'OK'
        ], 201);
    }


    public function remove_device_events(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        // nothing
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ],
            'delete_device_locations' => 'required|boolean',
            'delete_device_owners' => 'required|boolean',
            'delete_device_reseller' => 'required|boolean',
        ]);

        if ($request->input('device_id') == '862549042340490') {
            return response()->json([
                'status' => 'INVALID_DEVICE'
            ], 403);
        }

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        ResellerAuditLogs::save('REMOVE_DEVICE_DATA', [$request->input('device_id')]);

        if ($request->input('delete_device_locations')) {
            DB::table('events')
                ->where('device_id', $request->input('device_id'))
                ->delete();

            DB::table('heartbeats')
                ->where('device_id', $request->input('device_id'))
                ->delete();
        }

        if ($request->input('delete_device_owners')) {
            DB::table('device_owners')
                ->where('device_id', $request->input('device_id'))
                ->delete();

            DB::table('devices')
                ->where('id', $request->input('device_id'))
                ->update([
                    'user_id' => null,
                    'name' => null,
                    'plate_provincia' => null,
                    'plate_id' => null,
                    'plate_letter' => null,
                    'plate_city' => null,
                    'settings_time_interval' => null,
                    'settings_distance_interval' => null,
                    'settings_speed_limit' => null,
                    'settings_relay' => null,
                    'settings_master_phone' => null,
                    'send_settings_to_device' => null,
                    'updated_at' => date("Y-m-d H:i:s"),
                ]);
        }

        if (Auth::User()->role === 'admin') {
            if ($request->input('delete_device_expire_at')) {
                DB::table('device_owners')
                    ->where('device_id', $request->input('device_id'))
                    ->delete();

                DB::table('devices')
                    ->where('id', $request->input('device_id'))
                    ->update([
                        'user_id' => null,
                        'name' => null,
                        'plate_provincia' => null,
                        'plate_id' => null,
                        'plate_letter' => null,
                        'plate_city' => null,
                        'settings_time_interval' => null,
                        'settings_distance_interval' => null,
                        'settings_speed_limit' => null,
                        'settings_relay' => null,
                        'settings_master_phone' => null,
                        'send_settings_to_device' => null,
                        'expire_at' => null,
                        'updated_at' => date("Y-m-d H:i:s"),
                    ]);
            }

            if ($request->input('delete_device_whole_data')) {
                DB::table('devices')
                    ->where('id', $request->input('device_id'))
                    ->delete();

                DB::table('events')
                    ->where('device_id', $request->input('device_id'))
                    ->delete();

                DB::table('heartbeats')
                    ->where('device_id', $request->input('device_id'))
                    ->delete();

                DB::table('device_owners')
                    ->where('device_id', $request->input('device_id'))
                    ->delete();
            }
        }

        if ($request->input('delete_device_reseller')) {
            DB::table('devices')
                ->where('id', $request->input('device_id'))
                ->update([
                    'reseller_user_id' => null,
                    'updated_at' => date("Y-m-d H:i:s"),
                ]);
        }

        return response()->json([
            'status' => 'OK'
        ]);
    }

    public function get_location(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        // nothing
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ]
        ]);

        if ($request->input('device_id') == '862549042340490') {
            return response()->json([
                'status' => 'INVALID_DEVICE'
            ], 403);
        }

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $last_location = DB::table('events')
            ->select(
                'device_date_time',
                'type',
                DB::raw('ST_X(location) as latitude'),
                DB::raw('ST_Y(location) as longitude'),
                'heading as bearing',
                'speed',
                'altitude',
                'fix_mode',
                'satellites',
                'gps_signal_strength',
                'ACC',
                'gsm_signal_strength',
                'battery'
            )
            ->where('device_id', $request->input('device_id'))
            ->orderBy('device_date_time', 'DESC')
            ->first();

        ResellerAuditLogs::save('SEE_DEVICE_LOCATION', [$request->input('device_id')]);

        return response()->json([
            'status' => 'OK',
            'data' => [
                'id' => (int)$request->input('device_id'),
                'date' => $last_location->device_date_time ?? null,
                'latitude' => $last_location->latitude ?? null,
                'longitude' => $last_location->longitude ?? null,
                'bearing' => $last_location->bearing ?? null,
                'speed' => $last_location->speed ?? null,
                'altitude' => $last_location->altitude ?? null,
                'fix_mode' => $last_location->fix_mode ?? null,
                'satellites' => $last_location->satellites ?? null,
                'gps_signal_strength' => $last_location->gps_signal_strength ?? null,
                'gsm_signal_strength' => $last_location->gsm_signal_strength ?? null,
                'ACC' => $last_location->ACC ?? null,
                'battery' => $last_location->battery ?? null,
            ]
        ]);
    }

    public function get_device_users(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        // nothing
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ]
        ]);

        if ($request->input('device_id') == '862549042340490') {
            return response()->json([
                'status' => 'INVALID_DEVICE'
            ], 403);
        }

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $device = DB::table('devices')
            ->where('id', $request->input('device_id'))
            ->first();

        $users = DB::table('device_owners')
            ->select('users.*')
            ->leftJoin('users', 'users.id', 'user_id')
            ->where('device_id', $request->input('device_id'))
            ->where('user_id', '!=', 6)
            ->get();

        $result = [];
        foreach ($users as $user) {
            $result[] = [
                'id' => $user->id,
                'name' => $user->name,
                'phone' => '0' . substr($user->phone, 2),
                'created_at' => $user->created_at
            ];
        }

        return response()->json([
            'status' => 'OK',
            'data' => [
                'users' => $result,
                'device' => $device,
            ]
        ]);
    }

    public function add_user_to_device(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        // nothing
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ],
            'phone' => ['required', new phone]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        // Check if user exists
        $user = DB::table('users')
            ->where('phone', Functions::format_phone($request->input('phone')))
            ->first();

        if (!$user || Functions::format_phone($request->input('phone')) == '989302021988') {
            return response()->json([
                'status' => 'INVALID_USER',
                'message' => 'کاربر مورد نظر در سیستم موجود نیست. کاربر ابتدا باید ثبت‌نام کند.',
            ], 403);
        }

        if (DB::table('device_owners')
            ->where('user_id', $user->id)
            ->where('device_id', $request->input('device_id'))
            ->exists()) {
            return response()->json([
                'status' => 'INVALID_USER',
                'message' => 'کاربر قبلا به این دستگاه اضافه شده است.',
            ], 403);
        }

        DB::table('device_owners')
            ->insert([
                'device_id' => $request->input('device_id'),
                'user_id' => $user->id,
                'reseller_id' => Auth::id(),
            ]);

        return response()->json([
            'status' => 'OK'
        ]);
    }

    public function delete_user_from_device(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        // nothing
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ],
            'phone' => ['required', new phone]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        // Check if user exists
        $user = DB::table('users')
            ->where('phone', Functions::format_phone($request->input('phone')))
            ->first();

        if (!$user || Functions::format_phone($request->input('phone')) == '989302021988') {
            return response()->json([
                'status' => 'INVALID_USER',
                'message' => 'کاربر مورد نظر در سیستم موجود نیست. کاربر ابتدا باید ثبت‌نام کند.',
            ], 403);
        }

        DB::table('device_owners')
            ->where('device_id', $request->input('device_id'))
            ->where('user_id', $user->id)
            ->delete();

        return response()->json([
            'status' => 'OK'
        ]);
    }

    public function change_expire_at(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => [
                'required',
                'numeric',
                Rule::exists('devices', 'id')->where(function ($query) {
                    if (Auth::User()->role == 'store_keeper') {
                        $query->where('creator_reseller_user_id', Auth::id());
                    } elseif (Auth::User()->role == 'admin') {
                        // nothing
                    } else {
                        $query->where('reseller_user_id', Auth::id());
                    }
                }),
            ],
            'expire_at' => 'required|date|date_format:Y-m-d H:i:s'
        ]);

        if (Auth::User()->role === 'reseller') {
            return response()->json([
                'status' => 'INVALID_DEVICE',
                'message' => 'شما اجازه استفاده از این قابلیت را ندارید.',
            ], 403);
        }

        // Get Device
        $device = DB::table('devices')
            ->where('id', $request->input('device_id'))
            ->first();

        if (!$device) {
            return response()->json([
                'status' => 'INVALID_DEVICE',
                'message' => 'دستگاه مورد نظر در سیستم موجود نیست.',
            ], 403);
        }

        $device_expire_at = $device->expire_at ? strtotime($device->expire_at) : time();
        $new_expire_at = strtotime($request->input('expire_at'));

        if ($new_expire_at < time()) {
            return response()->json([
                'status' => 'INVALID_DEVICE',
                'message' => 'زمان صحبح نیست!',
            ], 403);
        }

        if (Auth::User()->role === 'store_keeper') {
            if ($new_expire_at - $device_expire_at > Auth::User()->credits * 24 * 60 * 60) {
                return response()->json([
                    'status' => 'INVALID_DEVICE',
                    'message' => 'اعتبار شما کافی نیست!',
                ], 403);
            }
        }

        DB::table('devices')
            ->where('id', $request->input('device_id'))
            ->update([
                'expire_at' => date('Y-m-d H:i:s', strtotime($request->input('expire_at'))),
                'updated_at' => now()
            ]);

        DB::table('reseller_users')
            ->where('id', Auth::id())
            ->decrement('credits', ceil(($new_expire_at - $device_expire_at) / 60 / 60 / 24));

        ResellerAuditLogs::save('CHANGE_DEVICE_CREDITS', [$request->input('device_id'), date('Y-m-d H:i:s', $device_expire_at), $request->input('expire_at')]);

        return response()->json([
            'status' => 'OK'
        ]);
    }
}
