<?php

namespace App\Http\Controllers;

use App\Libs\ResellerAuditLogs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AuditLogController extends Controller
{
    public function get(Request $request)
    {
        return response()->json([
            'status' => 'OK',
            'data' => ResellerAuditLogs::get()
        ]);
    }
}
