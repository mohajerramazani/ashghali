<?php

namespace App\Http\Controllers;

use App\Libs\ResellerAuditLogs;
use App\Rules\base64image;
use App\Rules\phone;
use Exception;
use http\Env\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App;
use App\Libs\Functions;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function get(Request $request)
    {
        $user = DB::table('reseller_users')
            ->select('name', 'username', 'role', 'created_at', 'updated_at', 'credits')
            ->where('id', Auth::id())
            ->first();

        return response()->json([
            'status' => 'OK',
            'user' => [
                'name' => $user->name,
                'username' => $user->username,
                'role' => $user->role,
                'credits' => $user->credits !== null ? ($user->credits > 365 ? (Functions::english2Persian_number(round($user->credits / 365)) . ' سال') : (Functions::english2Persian_number($user->credits) . ' روز')) : null,
                'created_at' => $user->created_at,
                'updated_at' => $user->updated_at,
            ]
        ]);
    }

    public function get_session(Request $request)
    {
        $objects = DB::table('reseller_tokens')
            ->select('id', 'device', 'platform', 'ip', 'location', 'provider', 'created_at')
            ->where('reseller_user_id', Auth::id())
            ->get();

        $result = [];
        foreach ($objects as $object) {
            $result[] = [
                'id' => (int)$object->id,
                'device' => $object->device,
                'platform' => $object->platform,
                'ip' => $object->ip,
                'location' => $object->location,
                'provider' => $object->provider,
                'created_at' => $object->created_at,
            ];
        }

        ResellerAuditLogs::save('VIEW_SESSIONS');

        return response()->json([
            'status' => 'OK',
            'data' => $result
        ]);
    }

    public function delete_session(Request $request, $id)
    {
        $validator = Validator::make(['id' => $id], [
            'id' => [
                'required',
                'numeric',
                Rule::exists('reseller_tokens')->where(function ($query) {
                    $query->where('reseller_user_id', Auth::id());
                }),
            ]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::table('reseller_tokens')
            ->where('id', $id)
            ->where('reseller_user_id', Auth::id())
            ->delete();

        ResellerAuditLogs::save('DELETE_A_SESSION', [$id]);

        return response()->json([
            'status' => 'OK'
        ]);
    }

    public function sign_in(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string|max:32',
            'password' => 'required|string|max:128'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        // Check if user exists
        $user = DB::table('reseller_users')
            ->where('username', $request->input('username'))
            ->first();

        if (!$user) {
            return response()->json([
                'status' => 'WRONG_CREDENTIALS',
                'message' => 'نام کاربری یا گذرواژه اشتباه می‌باشد.'
            ], 403);
        }


        if (Hash::check($request->input('password'), $user->password)) {
            Auth::onceUsingId($user->id);
            $token = dechex(Auth::id()) . 'H' . Functions::generate_random_string(64);

            // Get IP Information
            $location = json_decode(@file_get_contents('https://ipinfo.io/' . $request->ip() . '/json', false, stream_context_create(array('http'=>
                array(
                    'timeout' => 10,
                )
            ))) ,1);

            $browser = new App\Libs\Browser();

            DB::table('reseller_tokens')->insert([
                'reseller_user_id' => Auth::id(),
                'token' => md5(md5(explode('H', $token)[1])),
                'device' => (($browser->getBrowser() != 'unknown') ? ($browser->getBrowser() . ' ') : '') . $browser->getVersion(),
                'platform' => $browser->getPlatform(),
                'ip' => $request->ip(),
                'location' => ($location['city'] ?? '-') . '/' . ($location['country'] ?? '-'),
                'provider' => $location['isp'] ?? '-',
                'created_at' => date("Y-m-d H:i:s")
            ]);

            App\Libs\ResellerAuditLogs::save('LOGIN');

            return response()->json([
                'status' => 'OK',
                'user' => [
                    'name' => Auth::user()->name,
                    'username' => Auth::user()->username,
                    'role' => $user->role
                ],
                'token' => $token
            ]);
        }
        return response()->json([
            'status' => 'WRONG_CREDENTIALS',
            'message' => 'نام کاربری یا گذرواژه اشتباه می‌باشد.'
        ], 403);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function change_user_password(Request $request): JsonResponse
    {
    $validator = Validator::make($request->all(), [
        'old_password' => 'required|string|min:8|max:128',
        'new_password' => 'required|string|min:8|max:128'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 'VALIDATION_ERROR',
            'errors' => $validator->errors()
        ], 422);
    }

    if (Hash::check($request->input('old_password'), Auth::user()->password)) {
        DB::table('reseller_users')
            ->where('id', Auth::id())
            ->update([
                'password' => Hash::make($request->input('new_password')),
                'updated_at' => now(),
            ]);

        DB::table('reseller_tokens')
            ->where('reseller_user_id', Auth::id())
            ->delete();

        App\Libs\ResellerAuditLogs::save('CHANGE_PASSWORD');

        return response()->json([
            'status' => 'OK',
            'message' => 'گذرواژه با موفقیت تغییر کرد.'
        ]);
    }

    return response()->json([
        'status' => 'WRONG_CREDENTIALS',
        'message' => 'گذرواژه فعلی نادرست است.'
    ], 403);
}
}
