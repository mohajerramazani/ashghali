<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;

class generate_password extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'generate:password';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a new user password to place in database';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return integer
     */
    public function handle()
    {
        $this->alert("This is sensitive data!");
        $plain_password = $this->secret('Enter password', null);
        if ($plain_password === null) {
            $this->error('Password is empty!');
            return 1;
        }
        $this->info(Hash::make($plain_password));
        return 0;
    }
}
