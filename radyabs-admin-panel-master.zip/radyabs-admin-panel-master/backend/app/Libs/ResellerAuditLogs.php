<?php
/**
 * Created by PhpStorm.
 * User: Sky
 * Date: 01/02/2020
 * Time: 10:51
 */

namespace App\Libs;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ResellerAuditLogs
{
    /**
     * Save log in database
     * @param $action
     * @param array $values
     */
    static function save($action, array $values = null): void
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        // Sometimes $_SERVER["REMOTE_ADDR"] return multiple IPs
        $ip = trim(explode(",", $ip)[0]);

        // We don't store IPv6
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $ip = ip2long($ip);
        } else {
            $ip = ip2long('0.0.0.0');
        }

        DB::table('reseller_audit_logs')->insert([
            'reseller_user_id' => Auth::id(),
            'ip' => $ip,
            'action' => $action,
            'value' => $values ? json_encode($values) : null,
            'created_at' => date("Y-m-d H:i:s")
        ]);
    }


    static private function translate($action, array $values = null): string
    {
        switch ($action) {
            case 'LIST_OF_DEVICES':
                return "مشاهده لیست دستگاه‌ها.";
            case 'VIEW_SESSIONS':
                return "مشاهده نشست‌های فعال کاربر.";
            case 'LOGIN':
                return "ورود به سیستم.";
            case 'CHANGE_PASSWORD':
                return "تغییر رمز کاربر.";
            case 'DELETE_A_SESSION':
                return sprintf("پاک‌کردن نشست فعال به شماره‌ی «%s».", $values[0]);
            case 'WAREHOUSE_ADD_TRIAL_DEVICE':
                return sprintf("دستگاه آزمایشی «%s» به انبار اضافه شد.", $values[0]);
            case 'REMOVE_DEVICE_DATA':
                return sprintf("پاک‌کردن داده‌های دستگاه به شماره‌ی «%s».", $values[0]);
            case 'WAREHOUSE_ADD_DEVICE':
                return sprintf("دستگاه «%s» به انبار اضافه شد.", $values[0]);
            case 'SEE_DEVICE_LOCATION':
                return sprintf("آخرین موقعیت دستگاه «%s» مشاهده شد.", $values[0]);
            case 'CHANGE_DEVICE_CREDITS':
                return sprintf("اعتبار دستگاه «%s» از «%s» به «%s» تغییر یافت.", $values[0], $values[1], $values[2]);
            case 'DELETE_USER_FROM_DEVICE':
                return sprintf("کاربر «%s» از دستگاه «%s» حذف شد.", $values[0], $values[1]);
            case 'EDIT_CREDITS':
                return sprintf("اعتبار «%s» از «%s» سال به «%s» سال تغییر یافت.", $values[0], Functions::english2Persian_number(round($values[1] / 365)), Functions::english2Persian_number(round($values[2] / 365)));
            case 'GET_DEVICE_PASSWORD':
                return sprintf("مشاهده رمز دستگاه با شماره سریال «%s».", $values[0]);
            case 'RESELLER_MANAGER_DEVICE_SEARCH':
                return sprintf("جستجوی «%s» برای یافتن دستگاه در زمان اضافه کردن دستگاه به نماینده.", $values[0]);
            case 'RESELLER_MANAGER_ADD_DEVICE_TO_RESELLER':
                return sprintf("دستگاه با شماره سریال «%s» به نماینده «%s» با کد کاربری %s اضافه شد.", $values[0], $values[2], Functions::english2Persian_number($values[1]));
            default:
                return '-';
        }
    }


    static function get($all_users = false): array
    {
        $query = DB::table('reseller_audit_logs')
            ->select('reseller_audit_logs.*', 'reseller_users.username', 'reseller_users.name')
            ->leftJoin('reseller_users', 'reseller_audit_logs.reseller_user_id', 'reseller_users.id');
        if (!$all_users) {
            $query = $query->where('reseller_user_id', Auth::id());
        }
        $query = $query->orderBy('reseller_audit_logs.id', 'desc')->limit(1000)->get();

        $result = [];
        foreach ($query as $item) {
            $values = (array)json_decode($item->value);
            $result[] = [
                'ip' => long2ip($item->ip),
                'action' => $item->action,
                'user' => [
                    'username' => $item->username,
                    'name' => $item->name
                ],
                'value' => $values,
                'message' => self::translate($item->action, $values),
                'created_at' => $item->created_at
            ];
        }
        return $result;
    }
}
