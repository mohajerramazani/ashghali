<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class phone implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        //09302021988
        if (strlen($value) == 11 && strpos($value, '09') === 0) {
            return true;
        }

        //9302021988
        if (strlen($value) == 10 && strpos($value, '9') === 0) {
            return true;
        }

        //989302021988
        if (strlen($value) == 12 && strpos($value, '989') === 0) {
            return true;
        }

        //+989302021988
        if (strlen($value) == 13 && strpos($value, '+989') === 0) {
            return true;
        }

        //009809302021988
        if (strlen($value) == 15 && strpos($value, '009809') === 0) {
            return true;
        }

        //+9809302021988 || 00989302021988
        if ((strlen($value) == 14 && (strpos($value, '+980') === 0) || strpos($value, '00989') === 0)) {
            return true;
        }

        return false;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return trans('validation.phone');
    }
}
