import {Injectable} from '@angular/core';
import * as toastr from 'toastr';

@Injectable({
  providedIn: 'root'
})
export class ToastrService {
  toastr: Toastr;

  constructor() {
    toastr.options.closeButton = true;
    toastr.options.newestOnTop = true;

    toastr.options.rtl = true;
    toastr.options.positionClass = 'toast-bottom-right';
    this.toastr = toastr;
  }
}
