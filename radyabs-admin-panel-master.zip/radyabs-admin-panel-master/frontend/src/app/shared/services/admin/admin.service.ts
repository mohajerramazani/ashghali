import {Injectable} from '@angular/core';
import {HttpService} from 'src/app/shared/services/http.service';
import {map} from 'rxjs/operators';
import {PanelSummary} from 'src/app/shared/models/panel-summary';
import {StoreKeeper} from 'src/app/shared/models/store-keeper.model';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private http: HttpService) {
  }

  getSystemDetails() {
    return this.http
      .request('get', '/v1/panel-summary')
      .pipe(
        map((response: any) => response.data),
        map((data) => data.map(input => new PanelSummary(input))),
      );
  }

  getStoreKeeperList() {
    return this.http
      .request('get', '/v1/store-keeper')
      .pipe(
        map((response: any) => response.data),
        map((data) => data.map(input => new StoreKeeper(input))),
      );
  }

  updateStoreKeeperCredits(credits: number, id: number) {
    return this.http.request('put', '/v1/store-keeper', {
      credits: credits * 365,
      id
    });
  }
}
