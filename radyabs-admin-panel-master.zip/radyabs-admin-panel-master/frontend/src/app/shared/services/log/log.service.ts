import {Injectable} from '@angular/core';
import {HttpService} from '../http.service';
import {map} from 'rxjs/operators';
import {Log} from '../../models/log.model';

@Injectable({
  providedIn: 'root'
})
export class LogService {

  constructor(private http: HttpService) {
  }

  get log() {
    return this.http.request('get', '/v1/audit-log').pipe(
      map((response: any) => response.data),
      map((data) => data.map(each => new Log(each))),
    );
  }


}
