import {Injectable} from '@angular/core';
import {HttpService} from './http.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(private http: HttpService) {
  }

  signIn(username: string, password: string) {
    return this.http.request('post', '/v1/user', {
      username,
      password
    });
  }

  setToken(token: string, rememberMe: boolean) {
    if (rememberMe) {
      localStorage.setItem('token', token);
    } else {
      sessionStorage.setItem('token', token);
    }
  }

  set userRole(role: string) {
    localStorage.setItem('role', role);
  }

  get userRole() {
    return localStorage.getItem('role') || undefined;
  }

  signOut() {
    localStorage.clear();
    sessionStorage.clear();
  }

  checkUserSignedIn() {
    return !!localStorage.getItem('token') || !!sessionStorage.getItem('token') || false;
  }

  getToken() {
    return localStorage.getItem('token') || sessionStorage.getItem('token') || undefined;
  }
}
