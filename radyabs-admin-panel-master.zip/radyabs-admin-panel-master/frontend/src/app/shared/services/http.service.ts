import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {HttpError} from '../models/http-error.model';
import {catchError} from 'rxjs/operators';
import {throwError} from 'rxjs/internal/observable/throwError';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  baseUrl = 'https://reseller.radyabs.com/api';

  constructor(private http: HttpClient, public router: Router) {
  }

  public request(
    method: string,
    url: string,
    data = null,
    contentType = 'application/x-www-form-urlencoded'
  ): Observable<HttpResponse<any>> {
    const headers = new HttpHeaders({
      hl: 'en',
      'Content-Type': contentType,
    });
    if (data) {
      return this.http[method](`${this.baseUrl}${url}`, data, {
        headers
      }).pipe(catchError(this.authentication.bind(this)));
    }
    return this.http[method](`${this.baseUrl}${url}`, {
      headers
    }).pipe(catchError(this.authentication.bind(this)));
  }

  authentication(error: HttpError) {
    if (error.status === 401) {
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigateByUrl('/sign-in');
    }
    return throwError(error);
  }
}
