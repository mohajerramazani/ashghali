import {Injectable} from '@angular/core';
import {HttpService} from '../http.service';
import {map, shareReplay} from 'rxjs/operators';
import {User} from '../../models/user.model';
import {Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  refreshUserDate = new Subject<void>();

  constructor(private http: HttpService) {
  }

  getUser() {
    return this.http.request('get', '/v1/user').pipe(
      map((response: any) => response.user),
      map(user => new User(user)),
    );
  }

  changePassword(oldPassword: string, newPassword: string) {
    return this.http.request('put', '/v1/user/password', {
      oldPassword,
      newPassword
    });
  }
}
