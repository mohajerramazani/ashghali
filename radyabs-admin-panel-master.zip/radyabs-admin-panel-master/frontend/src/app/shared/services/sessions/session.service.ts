import {Injectable} from '@angular/core';
import {HttpService} from '../http.service';
import {map} from 'rxjs/operators';
import {Device} from '../../models/device.model';
import {Session} from '../../models/session.model';

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  constructor(private http: HttpService) {
  }

  getSessionsList() {
    return this.http.request('get', '/v1/user/session').pipe(
      map((response: any) => response.data),
      map(sessions => sessions.map(session => new Session(session)))
    );
  }

  removeSession(id: number) {
    return this.http.request('delete', `/v1/user/session/${id}`);
  }
}
