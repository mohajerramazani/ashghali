import {Injectable} from '@angular/core';
import {HttpService} from '../http.service';
import {catchError, map, shareReplay} from 'rxjs/operators';
import {Device} from '../../models/device.model';
import {Observable} from 'rxjs';
import {User} from 'src/app/shared/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class DeviceService {

  constructor(private http: HttpService) {
  }

  deviceList: Observable<any>;

  addDevice(data) {
    return this.http.request('post', '/v1/device/add', data);
  }

  addDeviceToReseller(data) {
    return this.http.request('post', '/v1/reseller-manager/add-device-to-reseller', data, 'application/json');
  }

  getDevicePassword(deviceId: string) {
    return this.http.request('post', '/v1/device/password', {
      deviceId
    }).pipe(map((response: any) => response.data));
  }

  getDeviceList() {
    if (this.deviceList === undefined) {
      this.deviceList = this.http.request('get', '/v1/device').pipe(
        map((response: any) => response.data),
        map(devices => devices.map(device => new Device(device))),
        catchError(error => {
          this.deviceList = undefined;
          throw error;
        }),
        shareReplay(1)
      );
    }
    return this.deviceList;
  }

  searchDevice(query: string) {
    return this.http.request('get', `/v1/reseller-manager/search-device?device=${query}`)
      .pipe(map((response: any) => response.data));
  }

  getDeviceVersionList() {
    return this.http.request('get', '/v1/store-keeper/device/version')
      .pipe(
        map((response: any) => response.data)
      );
  }

  getDeviceFirmwareList(versionId: number) {
    return this.http.request('get', `/v1/store-keeper/device/firmware?device_version_id=${versionId}`)
      .pipe(
        map((response: any) => response.data)
      );
  }

  addDeviceToStore(data) {
    return this.http.request('post', '/v1/store-keeper/device', data, 'application/json');
  }

  deleteDevice(deviceId: string, deleteDeviceOwners: boolean,
               deleteDeviceLocations: boolean,
               deleteDeviceReseller: boolean,
               deleteDeviceExpireAt: boolean,
               deleteDeviceWholeData: boolean) {
    return this.http.request('post', '/v1/device/remove', {
      device_id: deviceId,
      delete_device_locations: (deleteDeviceLocations) ? 1 : 0,
      delete_device_owners: (deleteDeviceOwners) ? 1 : 0,
      delete_device_reseller: (deleteDeviceReseller) ? 1 : 0,
      delete_device_expire_at: (deleteDeviceExpireAt) ? 1 : 0,
      delete_device_whole_data: (deleteDeviceWholeData) ? 1 : 0
    });
  }

  getDeviceLastLocation(id) {
    return this.http.request('get', `/v1/device/location?device_id=${id}`);
  }

  getDevicePhoneLists(id) {
    return this.http.request('get', `/v1/device/users?device_id=${id}`).pipe(
      map((response: any) => response.data),
      map((data: any) => ({
        device: new Device(data.device),
        users: data.users.map(user => new User(user))
      }))
    );
  }

  addPhone(deviceId, phone) {
    return this.http.request('post', '/v1/device/users', {
      deviceId,
      phone
    });
  }

  changeExpireAt(deviceId: string, expireAt: string) {
    return this.http.request('put', '/v1/device/expire-at', {
      deviceId,
      expireAt
    });
  }

  removePhoneFromDevice(deviceId, phone) {
    return this.http.request('delete', `/v1/device/users?device_id=${deviceId}&phone=${phone}`);
  }
}
