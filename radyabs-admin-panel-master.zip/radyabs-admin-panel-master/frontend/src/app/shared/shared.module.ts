import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {
  NbAlertModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbIconLibraries,
  NbIconModule,
  NbInputModule,
  NbLayoutModule,
  NbMenuModule,
  NbSidebarModule, NbUserModule, NbContextMenuModule, NbSelectModule
} from '@nebular/theme';
import {NbEvaIconsModule} from '@nebular/eva-icons';
import {ValidationErrorComponent} from './components/validation-error/validation-error.component';
import {JdatePipe} from './pipes/jdate.pipe';
import {FormatNumberPipe} from './pipes/format-number.pipe';
import {TimeAgoPipe} from './pipes/time-ago.pipe';
import {AutocompleteComponent} from './components/autocomplete/autocomplete.component';
import {OnlyDigitDirective} from 'src/app/shared/directives/only-digit.directive';
import {FormatMoneyPipe} from './pipes/format-money.pipe';
import {FixMonthDaysPipe} from 'src/app/shared/pipes/fix-month-days.pipe';
import {DatepickerComponent} from 'src/app/shared/components/datepicker/datepicker.component';

const components = [
  ValidationErrorComponent,
  AutocompleteComponent,
  DatepickerComponent
];
const pipes = [
  JdatePipe,
  FormatNumberPipe,
  TimeAgoPipe,
  FormatMoneyPipe
];

@NgModule({
  declarations: [...components, ...pipes, AutocompleteComponent, OnlyDigitDirective, FixMonthDaysPipe],
  imports: [
    CommonModule,
    NbIconModule,
    NbEvaIconsModule,
    NbAlertModule,
    NbInputModule,
    NbButtonModule,
    NbCheckboxModule,
    NbCardModule,
    NbLayoutModule,
    NbUserModule,
    NbSelectModule,
    NbSidebarModule.forRoot(),
    NbMenuModule.forRoot(),
    NbContextMenuModule,
  ],
  exports: [
    CommonModule,
    NbIconModule,
    NbEvaIconsModule,
    NbAlertModule,
    NbInputModule,
    NbButtonModule,
    NbCheckboxModule,
    NbCardModule,
    NbLayoutModule,
    NbSidebarModule,
    NbMenuModule,
    NbUserModule,
    NbSelectModule,
    NbContextMenuModule,
    ...components,
    ...pipes,
    OnlyDigitDirective

  ]
})
export class SharedModule {
  constructor(private iconLibraries: NbIconLibraries) {
    this.iconLibraries.registerFontPack('solid', {packClass: 'fas', iconClassPrefix: 'fa'});
    this.iconLibraries.registerFontPack('regular', {packClass: 'far', iconClassPrefix: 'fa'});
    this.iconLibraries.registerFontPack('light', {packClass: 'fal', iconClassPrefix: 'fa'});
    this.iconLibraries.registerFontPack('duotone', {packClass: 'fad', iconClassPrefix: 'fa'});
    this.iconLibraries.registerFontPack('brands', {packClass: 'fab', iconClassPrefix: 'fa'});
    this.iconLibraries.setDefaultPack('light');
  }
}
