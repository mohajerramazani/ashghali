import { OnlyDigitDirective } from './only-digit.directive';

describe('OnlyDigitDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyDigitDirective();
    expect(directive).toBeTruthy();
  });
});
