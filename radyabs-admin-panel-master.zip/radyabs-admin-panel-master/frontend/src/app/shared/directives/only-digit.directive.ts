import {Directive, ElementRef, EventEmitter, HostListener, Output} from '@angular/core';
import {NgModel} from '@angular/forms';

@Directive({
  selector: '[appOnlyDigit]',
  providers: [NgModel],

})
export class OnlyDigitDirective {

  private el: HTMLInputElement;
  @Output() ngModelChange: EventEmitter<any> = new EventEmitter();

  constructor(private elementRef: ElementRef, private model: NgModel) {
    this.el = this.elementRef.nativeElement;
  }

  @HostListener('input', ['$event']) onchange(event: any): void {
    const value = this.el.value?.toString();
    this.el.value = value.replace(/{\D.}/g, '');
    this.ngModelChange.emit(this.el.value);

  }

}
