import { JdatePipe } from './jdate.pipe';

describe('JdatePipe', () => {
  it('create an instance', () => {
    const pipe = new JdatePipe();
    expect(pipe).toBeTruthy();
  });
});
