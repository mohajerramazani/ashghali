import { FixMonthDaysPipe } from './fix-month-days.pipe';

describe('FixMonthDaysPipe', () => {
  it('create an instance', () => {
    const pipe = new FixMonthDaysPipe();
    expect(pipe).toBeTruthy();
  });
});
