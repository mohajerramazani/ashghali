import {Pipe, PipeTransform} from '@angular/core';
import moment from 'moment-jalaali';

@Pipe({
  name: 'fixMonthDays'
})
export class FixMonthDaysPipe implements PipeTransform {

  transform(days: [], ...args: unknown[]): unknown {
    if (args[0] <= 6 || !args[0]) {
      return days;
    }
    if (args[0] === 12 && !moment.jIsLeapYear(args[1])) {
      return days.slice(0, 29);
    }
    return days.slice(0, 30);
  }

}
