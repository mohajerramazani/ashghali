import {Pipe, PipeTransform} from '@angular/core';
import * as moment from 'moment-jalaali';

moment.loadPersian();

@Pipe({
  name: 'jdate'
})
export class JdatePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if (args[0] === 'withoutTime') {
      return moment(value, 'YYYY-MM-DD HH:mm').format('jYYYY/jMM/jDD');
    }
    return moment(value, 'YYYY-MM-DD HH:mm').format('HH:mm - jD jMMMM jYYYY');

  }

}
