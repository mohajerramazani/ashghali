import { FormatMoneyPipe } from './format-money.pipe';

describe('FormatMoneyPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatMoneyPipe();
    expect(pipe).toBeTruthy();
  });
});
