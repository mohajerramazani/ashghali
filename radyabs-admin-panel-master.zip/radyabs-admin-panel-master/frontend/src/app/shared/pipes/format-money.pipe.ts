import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'formatMoney'
})
export class FormatMoneyPipe implements PipeTransform {

  transform(value: string | undefined, ...args: unknown[]): string {
    if (isNaN(+value) === false) {
      return Intl.NumberFormat('en-US', {maximumSignificantDigits: 8}).format(+value);
    }
    return value;
  }

}
