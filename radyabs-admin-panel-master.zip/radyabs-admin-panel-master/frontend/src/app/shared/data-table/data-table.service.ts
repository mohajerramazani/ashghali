import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';
import {DataTableDirective} from 'angular-datatables';

@Injectable({
  providedIn: 'root'
})
export class DataTableService {
  dtOptions: DataTables.Settings = {
    pagingType: 'full_numbers',
    processing: true,

    pageLength: 100,
    language: {
      searchPlaceholder: 'جستجو کنید',
      emptyTable: 'هیچ داده‌ای در جدول وجود ندارد',
      info: 'نمایش _START_ تا _END_ از _TOTAL_ ردیف',
      infoEmpty: 'نمایش ۰ تا ۰ از ۰ ردیف',
      infoFiltered: '(فیلتر شده از _MAX_ ردیف)',
      infoPostFix: '',
      thousands: ',',
      lengthMenu: 'نمایش _MENU_ ردیف',
      loadingRecords: 'در حال بارگزاری...',
      processing: 'در حال پردازش...',
      search: 'جستجو:',
      zeroRecords: 'رکوردی با این مشخصات پیدا نشد',
      paginate: {
        first: 'برگه‌ی نخست',
        last: 'برگه‌ی آخر',
        next: 'بعدی',
        previous: 'قبلی'
      },
      aria: {
        sortAscending: ': فعال سازی نمایش به صورت صعودی',
        sortDescending: ': فعال سازی نمایش به صورت نزولی'
      }
    }
  };
  dtTrigger = new Subject();

  constructor() {
  }

  rerender(dtElement: DataTableDirective): void {
    if (dtElement === undefined || dtElement.dtInstance === undefined) {
      return;
    }
    dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }
}
