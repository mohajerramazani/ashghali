import {ChangeDetectionStrategy, Component, OnInit, Input, EventEmitter, Output, ChangeDetectorRef} from '@angular/core';

@Component({
  selector: 'app-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.scss'],
})
export class AutocompleteComponent implements OnInit {
  @Input() list = [];
  @Output() selected = new EventEmitter<string>();
  @Input() loading = false;
  visibility = false;

  @Input() set SetVisibility(value) {
    this.visibility = value;
  }

  constructor() {
  }

  selectItem(item: string) {
    this.selected.emit(item);
    console.log('selected');
  }

  ngOnInit() {
  }

}
