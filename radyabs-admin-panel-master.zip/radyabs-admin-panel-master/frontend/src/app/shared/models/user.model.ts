import {Utility} from 'src/app/core/interceptor/utility';

export class User {
  id: number;
  username: string;
  name = '....';
  token: string;
  role: string;
  createdAt: string;
  updatedAt: string;
  credits: number;
  phone: string;

  constructor(input = {}) {
    Object.assign(this, Utility.camelize(input));
  }
}
