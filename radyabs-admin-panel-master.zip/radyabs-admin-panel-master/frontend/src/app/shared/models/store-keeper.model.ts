export class StoreKeeper {
  id: number;
  username: string;
  role: string;
  credits: number;
  createdAt: string;
  updatedAt: string;

  constructor(input: any = {}) {
    this.id = input.id;
    this.username = input.username;
    this.role = input.role;
    this.credits = Math.round(input.credits / 365);
    this.createdAt = input.created_at;
    this.updatedAt = input.updated_at;
  }
}
