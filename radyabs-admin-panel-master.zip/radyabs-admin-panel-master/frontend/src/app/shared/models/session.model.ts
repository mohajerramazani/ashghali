import {Utility} from '../../core/interceptor/utility';

export class Session {
  id: number;
  createdAt: string;
  platform: string;
  location: string;
  ip: string;
  device: string;

  constructor(input = {}) {
    Object.assign(this, Utility.camelize(input));
  }
}
