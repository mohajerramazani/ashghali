export interface Version {
  name: string;
  id: number;
}
export interface Firmware {
  name: string;
  id: number;
}
