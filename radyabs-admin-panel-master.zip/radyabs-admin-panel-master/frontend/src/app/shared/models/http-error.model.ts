export class HttpError {
  status: number;
  error: string;
  validationError: {};

  constructor(error: any = {}) {
    Object.assign(this, error);
  }
}
