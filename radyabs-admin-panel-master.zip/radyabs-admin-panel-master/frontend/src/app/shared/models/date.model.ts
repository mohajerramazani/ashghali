export interface DateModel {
  day: number;
  month: number;
  year: number;
  hour: number;
  minute: number;
  second: number;
  timeIsDisabled: boolean;
}
