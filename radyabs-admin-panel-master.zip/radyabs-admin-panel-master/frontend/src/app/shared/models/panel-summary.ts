import {Utility} from 'src/app/core/interceptor/utility';

export class PanelSummary {
  name: string;
  value: string;
  description: string;

  constructor(input: any) {
    Object.assign(this, Utility.camelize(input));
  }

}
