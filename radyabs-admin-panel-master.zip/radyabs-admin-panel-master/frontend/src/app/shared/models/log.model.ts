import {Utility} from '../../core/interceptor/utility';

export class Log {
  ip: string;
  action: string;
  message: string;
  createdAt: string;

  constructor(input = {}) {
    Object.assign(this, Utility.camelize(input));
  }
}
