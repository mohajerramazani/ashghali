import {Utility} from '../../core/interceptor/utility';

export class Device {
  id: string;
  createdAt: string;
  deviceId: string;
  version: string;
  lastEvent: string;
  expireAt: string;
  name: string;
  devicePhone: string;

  constructor(input = {}) {
    Object.assign(this, Utility.camelize(input));
  }
}
