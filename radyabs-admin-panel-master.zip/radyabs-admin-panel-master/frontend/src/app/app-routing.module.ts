import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {SignInGuard} from './core/guards/sign-in.guard';

const routes: Routes = [{
    path: 'sign-in',
    loadChildren: () => import('./modules/auth/auth.module').then(m => m.AuthModule),
    canLoad: [SignInGuard]
  }]
;

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
