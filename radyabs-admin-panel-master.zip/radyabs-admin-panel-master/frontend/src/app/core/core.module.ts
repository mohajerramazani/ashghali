import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {httpInterceptorProviders} from './interceptor/http.interceptors';


@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
    httpInterceptorProviders
  ],
  exports: [
  ]
})
export class CoreModule {
}
