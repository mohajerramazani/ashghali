import { TestBed, async, inject } from '@angular/core/testing';

import { ResellerManagerGuard } from './reseller-manager.guard';

describe('ResellerManagerGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResellerManagerGuard]
    });
  });

  it('should ...', inject([ResellerManagerGuard], (guard: ResellerManagerGuard) => {
    expect(guard).toBeTruthy();
  }));
});
