import { TestBed, async, inject } from '@angular/core/testing';

import { ResellerGuard } from './reseller.guard';

describe('ResellerGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResellerGuard]
    });
  });

  it('should ...', inject([ResellerGuard], (guard: ResellerGuard) => {
    expect(guard).toBeTruthy();
  }));
});
