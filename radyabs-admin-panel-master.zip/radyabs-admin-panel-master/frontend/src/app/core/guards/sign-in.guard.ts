import {Injectable} from '@angular/core';
import {CanLoad, Route, Router, UrlSegment} from '@angular/router';
import {Observable} from 'rxjs';
import {AuthenticationService} from '../../shared/services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class SignInGuard implements CanLoad {
  constructor(private router: Router, private authenticationService: AuthenticationService) {
  }

  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authenticationService.checkUserSignedIn()) {
      this.router.navigate(['/']);
      return false;
    }
    return true;
  }
}
