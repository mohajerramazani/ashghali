import { TestBed, async, inject } from '@angular/core/testing';

import { DeviceListGuard } from './device-list.guard';

describe('DeviceListGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DeviceListGuard]
    });
  });

  it('should ...', inject([DeviceListGuard], (guard: DeviceListGuard) => {
    expect(guard).toBeTruthy();
  }));
});
