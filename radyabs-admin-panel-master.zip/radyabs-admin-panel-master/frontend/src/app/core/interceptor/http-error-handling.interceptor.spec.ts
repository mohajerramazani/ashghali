import { TestBed } from '@angular/core/testing';

import { HttpErrorHandlingInterceptor } from './http-error-handling.interceptor';

describe('HttpErrorHandlingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HttpErrorHandlingInterceptor = TestBed.get(HttpErrorHandlingInterceptor);
    expect(service).toBeTruthy();
  });
});
