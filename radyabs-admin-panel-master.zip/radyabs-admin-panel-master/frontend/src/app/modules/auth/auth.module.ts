import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';

import {AuthRoutingModule} from './auth-routing.module';
import {NbAuthModule} from '@nebular/auth';
import {SharedModule} from 'src/app/shared/shared.module';
import {SignInComponent} from './sign-in/sign-in.component';
import { AuthComponent } from './auth.component';


@NgModule({
  imports: [
    SharedModule,
    FormsModule,
    RouterModule,
    AuthRoutingModule,
    NbAuthModule.forRoot(),


  ],
  declarations: [
    SignInComponent,
    AuthComponent
  ],
  providers: []
})
export class AuthModule {

}
