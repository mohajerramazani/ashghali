import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuthenticationService} from '../../../shared/services/authentication.service';
import {HttpError} from '../../../shared/models/http-error.model';
import {Router} from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {
  validationErrors = {};
  messageError = '';
  username: string;
  password: string;
  submitted = false;
  rememberMe = false;

  constructor(private authenticationService: AuthenticationService, private router: Router) {
  }

  login(): void {
    this.submitted = true;
    this.authenticationService.signIn(this.username, this.password).subscribe((response: any) => {
      this.submitted = false;
      if (response.status === 'OK') {
        this.authenticationService.setToken(response.token, true);
        this.authenticationService.userRole = response.user.role;
        if (response.user.role === 'admin') {
          this.router.navigateByUrl('/admin/panel-summary');
        } else {
          this.router.navigateByUrl('/');
        }
      }
    }, (response: HttpError) => {
      this.submitted = false;
      if (response.status === 422) {
        this.validationErrors = response.validationError;
      } else {
        this.messageError = response.error;
      }
    });
  }


  ngOnInit(): void {
  }

}
