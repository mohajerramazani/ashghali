import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-auth',
  template: `
    <nb-layout>
      <nb-layout-column  >
        <div class="row d-flex justify-content-center align-content-center" >
          <div class="col-8">
            <nb-layout-column>
              <nb-card>
                <nb-card-body>
                  <nb-auth-block class="my-3" style="margin: auto">
                    <router-outlet></router-outlet>
                  </nb-auth-block>
                </nb-card-body>
              </nb-card>
            </nb-layout-column>
          </div>
        </div>
      </nb-layout-column>
    </nb-layout>
  `,
  styles: []
})
export class AuthComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
