import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AddDeviceStoreroomComponent} from './add-device-storeroom/add-device-storeroom.component';
import {AddDeviceToResellerComponent} from 'src/app/modules/dashboard/reseller-manager/add-device-to-reseller/add-device-to-reseller.component';


const routes: Routes = [{
  path: '',
  children: [
    {
      path: '',
      redirectTo: 'device/warehouse/add',
      pathMatch: 'full'
    },
    {
      path: 'device/reseller/add',
      component: AddDeviceToResellerComponent,
    },
    {
      path: 'device/warehouse/add',
      component: AddDeviceStoreroomComponent,

    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StorekeeperRoutingModule {
}
