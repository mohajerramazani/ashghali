import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDeviceStoreroomComponent } from './add-device-storeroom.component';

describe('AddDeviceStoreroomComponent', () => {
  let component: AddDeviceStoreroomComponent;
  let fixture: ComponentFixture<AddDeviceStoreroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDeviceStoreroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDeviceStoreroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
