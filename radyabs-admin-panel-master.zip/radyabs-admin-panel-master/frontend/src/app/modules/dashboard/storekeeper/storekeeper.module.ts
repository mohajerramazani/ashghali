import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {StorekeeperRoutingModule} from './storekeeper-routing.module';
import {SharedModule} from '../../../shared/shared.module';
import {FormsModule} from '@angular/forms';
import {AddDeviceStoreroomComponent} from './add-device-storeroom/add-device-storeroom.component';
import {ResellerManagerModule} from 'src/app/modules/dashboard/reseller-manager/reseller-manager.module';


@NgModule({
  declarations: [
    AddDeviceStoreroomComponent
  ],
  imports: [
    ResellerManagerModule,
    SharedModule,
    FormsModule,
    StorekeeperRoutingModule
  ]
})
export class StorekeeperModule {
}
