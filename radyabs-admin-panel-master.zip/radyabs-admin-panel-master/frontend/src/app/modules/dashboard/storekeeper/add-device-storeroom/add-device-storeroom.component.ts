import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {DeviceService} from '../../../../shared/services/device/device.service';
import {ToastrService} from '../../../../shared/services/toastr/toastr.service';
import {HttpError} from '../../../../shared/models/http-error.model';
import * as XLSX from 'xlsx/dist/xlsx.core.min';
import {Version, Firmware} from '../../../../shared/models/version.interface';
import * as moment from 'moment-jalaali';
import {UserService} from 'src/app/shared/services/user/user.service';

@Component({
  selector: 'app-add-device-storeroom',
  templateUrl: './add-device-storeroom.component.html',
  styleUrls: ['./add-device-storeroom.component.scss']
})
export class AddDeviceStoreroomComponent implements OnInit {

  device: string;
  username: string;
  firmwareList: Firmware[] = [];
  builtDay = {} as {
    day: number,
    month: number,
    year: number
  };
  versionId: number;
  firmwareId: number;
  sending = false;
  validationErrors = {};
  message: string;
  loading = false;
  devices: string[] = [];
  excelUploadLoading = false;
  excelMode = false;
  resellerUsername: string;
  versionList: Version[] = [];
  monthList = [
    'فروردین',
    'اردیبهشت',
    'خرداد',
    'تیر',
    'مرداد',
    'شهریور',
    'مهر',
    'آبان',
    'آذر',
    'دی',
    'بهمن',
    'اسفند',
  ];
  yearsList = [];
  daysList = [];
  trial = false;

  constructor(
    private deviceService: DeviceService,
    private toastrService: ToastrService,
    private cd: ChangeDetectorRef,
    private userService: UserService
  ) {
    this.yearsList = Array.from({
      length: 1 + Math.abs(1410 - 1395)
    }, (_, i) => 1395 + i);
    this.daysList = Array.from({
      length: 1 + Math.abs(31 - 1)
    }, (_, i) => 1 + i);
  }

  parseExcel(file) {
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const data = e.target.result;
      const workbook = XLSX.read(data, {
        type: 'binary'
      });
      if (workbook.SheetNames.length > 0) {
        const sheetName = workbook.SheetNames[0];
        const excelFile = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
        for (const row of excelFile) {
          this.devices.push(Object.values(row)[0] as string);
        }
      }
      this.excelUploadLoading = false;
      this.excelMode = true;
    };
    reader.onerror = (ex) => {
      console.log(ex);
    };
    reader.readAsBinaryString(file);
  }


  incomingFile(event) {
    const file = event.target.files[0];
    this.excelUploadLoading = true;
    this.parseExcel(file);
  }


  addDeviceToStore() {
    this.validationErrors = {};
    this.sending = true;
    this.deviceService.addDeviceToStore({
      username: this.resellerUsername,
      deviceFirmwareId: this.firmwareId,
      builtAt: moment(`${this.builtDay.year} ${this.builtDay.month} ${this.builtDay.day}`, 'jYYYY-jM-jD').format('YYYY-MM-DD HH:mm:ss'),
      device: (this.excelMode) ? this.devices : [this.device],
      trial: this.trial
    }).subscribe((response: any) => {
      if (response.status === 'OK') {
        this.toastrService.toastr.success(response.message);
        this.deviceService.deviceList = undefined;
        this.userService.refreshUserDate.next();
      }
      this.sending = false;
      this.devices = [];
      this.device = undefined;
      this.username = undefined;
      this.excelMode = false;
    }, (response: HttpError) => {
      if (response.status === 422) {
        this.validationErrors = response.validationError;
      } else if (response.status === 400) {
        this.message = response.error;
      }
      this.sending = false;
      this.excelMode = false;
    });
  }

  getFirmwareList(deviceVersion: number) {
    this.deviceService.getDeviceFirmwareList(deviceVersion).subscribe((firmwareList) => {
      this.firmwareList = firmwareList;
      if (this.firmwareList.length > 0) {
        this.firmwareId = this.firmwareList[0].id;
      }
    });

  }

  ngOnInit() {
    const m = moment();
    m.locale('fa');
    const today = m.format('jYYYY jMM jDD').split(' ');
    this.builtDay = {
      day: +today[2],
      month: +today[1],
      year: +today[0],
    };
    this.deviceService.getDeviceVersionList().subscribe((versionList: Version[]) => {
      this.versionList = versionList || [];
      if (this.versionList.length > 0) {
        this.versionId = this.versionList[0].id;
        this.getFirmwareList(this.versionId);
      }
    });
  }

}
