import {AfterViewInit, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {DataTableDirective} from 'angular-datatables';
import {DataTableService} from 'src/app/shared/data-table/data-table.service';
import {AdminService} from 'src/app/shared/services/admin/admin.service';
import {StoreKeeper} from 'src/app/shared/models/store-keeper.model';
import {ToastrService} from 'src/app/shared/services/toastr/toastr.service';
import {HttpError} from 'src/app/shared/models/http-error.model';

@Component({
  selector: 'app-store-keeper',
  templateUrl: './store-keeper.component.html',
  styleUrls: ['./store-keeper.component.scss']
})
export class StoreKeeperComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  storeKeepers: StoreKeeper[] = [];
  loader = false;
  selectedKeeper: StoreKeeper;
  updateLoader = false;

  constructor(public dataTable: DataTableService, private adminService: AdminService, private toastrService: ToastrService) {
  }

  getStoreKeeperList() {
    this.loader = true;
    this.adminService.getStoreKeeperList().subscribe((storeKeepers) => {
      this.storeKeepers = storeKeepers;
      this.dataTable.rerender(this.dtElement);
      this.loader = false;
    });
  }

  updateCredits(storeKeeper: StoreKeeper) {
    this.selectedKeeper = storeKeeper;
    this.updateLoader = true;
    this.adminService.updateStoreKeeperCredits(storeKeeper.credits, storeKeeper.id).subscribe((response: any) => {
      this.toastrService.toastr.success('اعتبار انباردار با موفقیت بروزرسانی شد.');
      this.updateLoader = false;
    }, (response: HttpError) => {
      if (response.status === 422) {
        const errors: any = response.validationError;
        if (errors.credits !== undefined) {
          this.toastrService.toastr.error(errors.credits[0]);
        }
      } else {
        this.toastrService.toastr.error(response.error);
      }
      this.updateLoader = false;
    });
  }

  getTime(value) {
    return new Date(value).getTime();
  }

  ngAfterViewInit(): void {
    this.dataTable.dtTrigger.next();
  }

  ngOnInit(): void {
    this.getStoreKeeperList();
  }

  ngOnDestroy(): void {
    this.dataTable.dtTrigger.unsubscribe();
  }

}
