import {Component, OnInit} from '@angular/core';
import {AdminService} from 'src/app/shared/services/admin/admin.service';
import {PanelSummary} from 'src/app/shared/models/panel-summary';

@Component({
  selector: 'app-system-details',
  templateUrl: './system-details.component.html',
  styleUrls: ['./system-details.component.scss']
})
export class SystemDetailsComponent implements OnInit {
  panelSummary: PanelSummary[] = [];
  loader = false;

  constructor(private adminService: AdminService) {
  }

  ngOnInit() {
    this.loader = true;
    this.adminService.getSystemDetails().subscribe((panelSummary) => {
      this.panelSummary = panelSummary;
      this.loader = false;
    });
  }

}
