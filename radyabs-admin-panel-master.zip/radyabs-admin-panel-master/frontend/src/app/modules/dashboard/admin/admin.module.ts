import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { StoreKeeperComponent } from './store-keeper/store-keeper.component';
import {NbCardModule, NbSpinnerModule} from '@nebular/theme';
import {DataTablesModule} from 'angular-datatables';
import {SharedModule} from 'src/app/shared/shared.module';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [StoreKeeperComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    NbCardModule,
    DataTablesModule,
    SharedModule,
    FormsModule,
    NbSpinnerModule
  ]
})
export class AdminModule { }
