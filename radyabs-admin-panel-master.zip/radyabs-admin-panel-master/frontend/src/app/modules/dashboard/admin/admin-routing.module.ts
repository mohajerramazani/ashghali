import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SystemDetailsComponent} from './system-details/system-details.component';
import {StoreKeeperComponent} from './store-keeper/store-keeper.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        redirectTo: 'panel-summary',
        pathMatch: 'full'
      },
      {
        path: 'panel-summary',
        component: SystemDetailsComponent
      },
      {
        path: 'store-keeper',
        component: StoreKeeperComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {
}
