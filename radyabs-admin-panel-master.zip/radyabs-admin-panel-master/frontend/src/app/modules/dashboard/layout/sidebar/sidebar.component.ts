import {Component, OnInit} from '@angular/core';
import {NbMenuItem, NbMenuService} from '@nebular/theme';
import {Router} from '@angular/router';
import {AuthenticationService} from '../../../../shared/services/authentication.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  items: NbMenuItem[] = [];

  constructor(menu: NbMenuService, private router: Router, private authenticationService: AuthenticationService) {
    menu.onItemClick().subscribe((event) => {
      if (event.item.link === '/sign-out') {
        this.authenticationService.signOut();
        this.router.navigateByUrl('/sign-in');
      }
    });
    if (authenticationService.userRole === 'reseller') {
      this.items = [
        {
          title: 'لیست دستگاه‌ها',
          link: '/devices',
          icon: 'cars',
        },
        {
          title: 'افزودن دستگاه',
          link: '/reseller/device/add',
          icon: 'plus',
        },
        {
          title: 'تغییر گذرواژه',
          link: '/change-password',
          icon: 'lock-alt',
        },
        {
          title: 'وقایع',
          link: '/logs',
          icon: 'file-alt',
        },
      ];
    }
    if (authenticationService.userRole === 'reseller_manager') {
      this.items = [
        {
          title: 'افزودن دستگاه',
          link: '/reseller-manager/device/add',
          icon: 'plus',
        },
        {
          title: 'تغییر گذرواژه',
          link: '/change-password',
          icon: 'lock-alt',
        },
        {
          title: 'وقایع',
          link: '/logs',
          icon: 'file-alt',
        },
      ];
    }
    if (authenticationService.userRole === 'store_keeper') {
      this.items = [
        {
          title: 'لیست دستگاه‌ها',
          link: '/devices',
          icon: 'cars',
        },
        {
          title: 'افزودن دستگاه به انبار',
          link: '/store-keeper/device/warehouse/add',
          icon: 'plus',
        },
        {
          title: 'افزودن دستگاه به فروشنده',
          link: '/store-keeper/device/reseller/add',
          icon: 'plus',
        },
        {
          title: 'تغییر گذرواژه',
          link: '/change-password',
          icon: 'lock-alt',
        },
        {
          title: 'وقایع',
          link: '/logs',
          icon: 'file-alt',
        },
      ];
    }
    if (authenticationService.userRole === 'admin') {
      this.items = [
        {
          title: 'جزئیات سامانه',
          link: '/admin/panel-summary',
          icon: 'sliders-h',
        },
        {
          title: 'لیست دستگاه‌ها',
          link: '/devices',
          icon: 'cars',
        },
        {
          title: 'لیست انباردار‌ها',
          link: '/admin/store-keeper',
          icon: 'person-dolly',
        },
        {
          title: 'تغییر گذرواژه',
          link: '/change-password',
          icon: 'lock-alt',
        },
        {
          title: 'وقایع',
          link: '/logs',
          icon: 'file-alt',
        },
      ];
    }
  }


  ngOnInit() {
  }

}
