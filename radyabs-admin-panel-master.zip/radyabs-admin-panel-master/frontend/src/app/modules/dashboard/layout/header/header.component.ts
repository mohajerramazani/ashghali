import {Component, OnDestroy, OnInit} from '@angular/core';
import {NbMenuService, NbSidebarService} from '@nebular/theme';
import {Router} from '@angular/router';
import {AuthenticationService} from 'src/app/shared/services/authentication.service';
import {UserService} from 'src/app/shared/services/user/user.service';
import {User} from 'src/app/shared/models/user.model';
import {DeviceService} from 'src/app/shared/services/device/device.service';
import {SubSink} from 'subsink';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  user: User = new User();
  sidebar = false;
  private sub = new SubSink();
  items = [
    {
      title: 'نشست‌های فعال',
      link: '/active-sessions',
      icon: 'lock'
    },
    {
      title: 'خروج',
      link: '/sign-out',
      icon: 'sign-out'
    }];

  constructor(
    private menu: NbMenuService,
    private userService: UserService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private sidebarService: NbSidebarService,
    private deviceService: DeviceService
  ) {
    menu.onItemClick().subscribe((event) => {
      if (event.item.link === '/sign-out') {
        this.authenticationService.signOut();
        this.deviceService.deviceList = undefined;
        this.router.navigateByUrl('/sign-in');
      }
    });
  }

  changeSidebar() {
    if (!this.sidebar) {
      this.sidebarService.compact('sidebar');
    } else {
      this.sidebarService.collapse('sidebar');
    }
    this.sidebar = !this.sidebar;
  }

  getUser() {
    this.sub.sink = this.userService.getUser().subscribe((user) => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.getUser();
    this.sub.sink = this.userService.refreshUserDate.subscribe(() => {
      this.getUser();
    });
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }


}
