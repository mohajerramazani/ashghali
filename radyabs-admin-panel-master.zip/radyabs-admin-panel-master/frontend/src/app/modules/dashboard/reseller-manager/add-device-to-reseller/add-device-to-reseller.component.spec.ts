import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDeviceToResellerComponent } from './add-device-to-reseller.component';

describe('AddDeviceToResellerComponent', () => {
  let component: AddDeviceToResellerComponent;
  let fixture: ComponentFixture<AddDeviceToResellerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDeviceToResellerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDeviceToResellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
