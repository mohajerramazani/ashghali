import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {ResellerManagerRoutingModule} from './reseller-manager-routing.module';
import {AddDeviceToResellerComponent} from './add-device-to-reseller/add-device-to-reseller.component';
import {SharedModule} from '../../../shared/shared.module';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [
    AddDeviceToResellerComponent
  ],
  imports: [
    SharedModule,
    FormsModule,
    ResellerManagerRoutingModule
  ],
  exports: [
    AddDeviceToResellerComponent
  ]
})
export class ResellerManagerModule {
}
