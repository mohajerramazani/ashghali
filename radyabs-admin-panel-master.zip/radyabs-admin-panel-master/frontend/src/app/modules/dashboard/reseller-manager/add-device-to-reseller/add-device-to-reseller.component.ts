import {ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import {Device} from '../../../../shared/models/device.model';
import {DeviceService} from '../../../../shared/services/device/device.service';
import {ToastrService} from '../../../../shared/services/toastr/toastr.service';
import {HttpError} from '../../../../shared/models/http-error.model';
import * as XLSX from 'xlsx/dist/xlsx.core.min';

@Component({
  selector: 'app-add-device-to-reseller',
  templateUrl: './add-device-to-reseller.component.html',
  styleUrls: ['./add-device-to-reseller.component.scss']
})
export class AddDeviceToResellerComponent implements OnInit, OnDestroy {


  device: string;
  username: string;
  sending = false;
  validationErrors = {};
  message: string;
  searchResult: { deviceId: string }[] = [];
  autoCompleteVisibility = false;
  loading = false;
  devices: string[] = [];
  excelUploadLoading = false;
  excelMode = false;
  documentEvent: string;

  constructor(private deviceService: DeviceService, private toastrService: ToastrService, private cd: ChangeDetectorRef) {
  }

  selectDeviceId(id: string) {
    this.device = id;
    this.devices = [id];
    this.autoCompleteVisibility = false;
  }

  parseExcel(file) {
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const data = e.target.result;
      const workbook = XLSX.read(data, {
        type: 'binary'
      });
      if (workbook.SheetNames.length > 0) {
        const sheetName = workbook.SheetNames[0];
        const excelFile = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
        for (const row of excelFile) {
          this.devices.push(Object.values(row)[0] as string);
        }
      }
      this.excelUploadLoading = false;
      this.excelMode = true;
      this.autoCompleteVisibility = false;
    };
    reader.onerror = (ex) => {
      console.log(ex);
    };
    reader.readAsBinaryString(file);
  }


  incomingFile(event) {
    const file = event.target.files[0];
    this.excelUploadLoading = true;
    this.parseExcel(file);
  }

  searchDevice(query: string) {
    this.loading = true;
    this.device = query;
    this.devices = [query];
    this.deviceService.searchDevice(query).subscribe((response: any) => {
      this.searchResult = response;
      this.autoCompleteVisibility = true;
      this.loading = false;
    }, () => {
      this.loading = false;
    });

  }

  addDeviceToReseller() {
    this.message = undefined;
    this.validationErrors = {};
    this.sending = true;
    this.deviceService.addDeviceToReseller({
      device: this.devices,
      username: this.username
    }).subscribe((response: any) => {
      if (response.status === 'OK') {
        this.toastrService.toastr.success(response.message);

      }
      this.sending = false;
      this.devices = [];
      this.device = undefined;
      this.username = undefined;
      this.excelMode = false;
    }, (response: HttpError) => {
      if (response.status === 422) {
        this.validationErrors = response.validationError;
      } else if (response.status === 400) {
        this.message = response.error;
      }
      this.sending = false;
      this.excelMode = false;
    });
  }

  hiddenAutoComplete() {
    this.autoCompleteVisibility = false;
  }

  ngOnInit() {
    this.deviceService.getDeviceList().subscribe((devices) => {
      this.devices = devices;
    });
    document.addEventListener('click', this.hiddenAutoComplete.bind(this));
  }

  ngOnDestroy(): void {
    document.removeEventListener('click', this.hiddenAutoComplete);
  }
}
