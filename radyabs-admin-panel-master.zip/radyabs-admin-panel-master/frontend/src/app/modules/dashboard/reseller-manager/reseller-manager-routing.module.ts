import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddDeviceToResellerComponent} from './add-device-to-reseller/add-device-to-reseller.component';
import {ResellerManagerGuard} from '../../../core/guards/reseller-manager.guard';


const routes: Routes = [{
  path: '',
  children: [
    {
      path: '',
      redirectTo: 'device/add',
      pathMatch: 'full'
    },
    {
      path: 'device/add',
      component: AddDeviceToResellerComponent,
      canActivate: [ResellerManagerGuard]

    }
  ]
}];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ResellerManagerRoutingModule { }
