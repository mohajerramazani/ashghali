import {Component, OnInit, ViewChild, AfterViewInit, OnDestroy} from '@angular/core';
import {Subject} from 'rxjs';
import {SessionService} from 'src/app/shared/services/sessions/session.service';
import {Session} from '../../../../shared/models/session.model';
import {ToastrService} from '../../../../shared/services/toastr/toastr.service';
import {DataTableDirective} from 'angular-datatables';
import {DataTableService} from '../../../../shared/data-table/data-table.service';

@Component({
  selector: 'app-sessions',
  templateUrl: './sessions.component.html',
  styleUrls: ['./sessions.component.scss']
})
export class SessionsComponent implements OnInit, AfterViewInit, OnDestroy {
  removedSessionId = -1;
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  sessions: Session[] = [];

  constructor(
    private sessionService: SessionService,
    private toastrService: ToastrService,
    public dataTable: DataTableService
  ) {
  }

  getTime(value) {
    return new Date(value).getTime();
  }

  remove(session: Session) {
    this.removedSessionId = session.id;
    this.sessionService.removeSession(session.id).subscribe((response: any) => {
      if (response.status === 'OK') {
        this.sessions.splice(this.sessions.indexOf(session), 1);
        this.dataTable.rerender(this.dtElement);
        this.toastrService.toastr.success('نشست با موفقیت حذف شد.');
        this.removedSessionId = -1;
        this.getSessions();
      }
    });
  }

  ngAfterViewInit(): void {
    this.dataTable.dtTrigger.next();
  }


  getSessions() {
    this.sessionService.getSessionsList().subscribe((sessions) => {
      this.sessions = sessions;
      this.dataTable.rerender(this.dtElement);
    });
  }

  ngOnInit() {
    this.dataTable.dtTrigger = new Subject();
    this.getSessions();
  }

  ngOnDestroy(): void {
    this.dataTable.dtTrigger.unsubscribe();
  }

}
