import {AfterContentChecked, AfterViewInit, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {DeviceService} from '../../../../shared/services/device/device.service';
import {Device} from '../../../../shared/models/device.model';
import {Subject} from 'rxjs';
import {DataTableDirective} from 'angular-datatables';
import {DataTableService} from '../../../../shared/data-table/data-table.service';
import Swal from 'sweetalert2';
import {AuthenticationService} from 'src/app/shared/services/authentication.service';
import {map, Map, tileLayer, marker, Marker, Icon} from 'leaflet';

declare const $: any;

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.scss']
})
export class DevicesComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  devices: Device[] = [];
  getPasswordLoading = false;
  password: string;
  loader = false;
  deleteDeviceLocations: boolean;
  deleteDeviceOwners: boolean;
  deleteDeviceReseller: boolean;
  deleteDeviceExpireAt: boolean;
  deleteDeviceWholeData: boolean;
  map: Map;
  getLastLocationLoading = false;
  noLastLocation = false;
  marker: Marker;
  role: string;

  constructor(private deviceService: DeviceService, public dataTable: DataTableService, private authenticationService: AuthenticationService) {
  }

  getDevicePassword(deviceId: string) {
    this.getPasswordLoading = true;
    this.deviceService.getDevicePassword(deviceId).subscribe((response: any) => {
      this.getPasswordLoading = false;
      this.password = response.password;
    });
  }

  deleteDevice(device: Device) {
    const role = this.authenticationService.userRole;
    let deleteHtml = `<div class="d-flex flex-column justify-content-center align-items-start">
        <div class="custom-control custom-checkbox">
             <input  type="checkbox" checked class="custom-control-input" id="customCheck1">
              <label class="custom-control-label" for="customCheck1">پاک‌کردن تمامی موقعیت‌های دستگاه</label>
        </div>
        <div class="custom-control custom-checkbox">
             <input type="checkbox" checked class="custom-control-input" id="customCheck2">
              <label class="custom-control-label" for="customCheck2">پاک کردن تمامی دارندگان از دستگاه</label>
         </div>
         <div class="custom-control custom-checkbox">
             <input type="checkbox" class="custom-control-input" id="customCheck3">
              <label class="custom-control-label" for="customCheck3">پاک‌کردن دستگاه از لیست دستگاه‌های فروشنده</label>
         </div>
     </div>`;
    if (role === 'admin') {
      deleteHtml = `
     <div class="d-flex flex-column justify-content-center align-items-start">
         <div class="custom-control custom-checkbox">
             <input  type="checkbox" checked class="custom-control-input" id="customCheck1">
              <label class="custom-control-label" for="customCheck1">پاک‌کردن تمامی موقعیت‌های دستگاه</label>
         </div>
         <div class="custom-control custom-checkbox">
             <input type="checkbox" checked class="custom-control-input" id="customCheck2">
              <label class="custom-control-label" for="customCheck2">پاک کردن تمامی دارندگان از دستگاه</label>
         </div>
         <div class="custom-control custom-checkbox">
             <input type="checkbox" class="custom-control-input" id="customCheck3">
              <label class="custom-control-label" for="customCheck3">پاک‌کردن دستگاه از لیست دستگاه‌های فروشنده</label>
         </div>
         <div class="custom-control custom-checkbox">
             <input type="checkbox" class="custom-control-input" id="customCheck4">
              <label class="custom-control-label" for="customCheck4">بازنشانی زمان انقضای دستگاه</label>
         </div>
         <div class="text-hint" style="text-align: right;font-size: small;padding-right: 1rem;">با بازنشانی زمان اطلاعات دستگاه اطلاعات دستگاه و همچنین دارندگان دستگاه نیز حذف می‌شوند</div>
         <div class="custom-control custom-checkbox">
             <input type="checkbox" class="custom-control-input is-invalid" id="customCheck5">
              <label class="custom-control-label" for="customCheck5">پاک کردن دستگاه به صورت کلی از سیستم</label>
         </div>
         <div class="text-hint" style="text-align: right;font-size: small;padding-right: 1rem;">دستگاه به صورت کلی از سیستم حذف می‌شود و باید آن را دوباره اضافه کرد.</div>
    </div>`;
    }
    Swal.fire({
      title: 'آیا مطمئن هستید؟',
      icon: 'error',
      html: deleteHtml,
      showCloseButton: false,
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      focusConfirm: false,
      confirmButtonText: 'حذف',
      cancelButtonText: 'انصراف',
      onRender(popup: HTMLElement) {
        if (role === 'admin') {
          $('#customCheck5').click(() => {
            if ($('#customCheck5').prop('checked')) {
              $('#customCheck4').prop('checked', true);
              $('#customCheck3').prop('checked', true);
              $('#customCheck2').prop('checked', true);
              $('#customCheck1').prop('checked', true);
            }
          });
        }
      }
    }).then((result) => {
      if (result.value) {
        this.deleteDeviceLocations = (document.getElementById('customCheck1') as HTMLInputElement).checked;
        this.deleteDeviceOwners = (document.getElementById('customCheck2') as HTMLInputElement).checked;
        this.deleteDeviceReseller = (document.getElementById('customCheck3') as HTMLInputElement).checked;
        if (role === 'admin') {
          this.deleteDeviceExpireAt = (document.getElementById('customCheck4') as HTMLInputElement).checked;
          this.deleteDeviceWholeData = (document.getElementById('customCheck5') as HTMLInputElement).checked;
        } else {
          this.deleteDeviceExpireAt = undefined;
          this.deleteDeviceWholeData = undefined;
        }
        this.deviceService
          .deleteDevice(device.deviceId,
            this.deleteDeviceOwners,
            this.deleteDeviceLocations,
            this.deleteDeviceReseller,
            this.deleteDeviceExpireAt, this.deleteDeviceWholeData)
          .subscribe((response: any) => {
            if (response.status === 'OK') {
              Swal.fire(
                'حذف شد!',
                'اطلاعات دستگاه با موفقیت حذف گردید.',
                'success'
              );
              this.deviceService.deviceList = undefined;
              this.getDeviceList();
            }
          });
      }
    });
  }

  getTime(value) {
    return new Date(value).getTime();
  }

  getColor(value) {
    const now = new Date();
    const diff = (now.getTime() - new Date(value).getTime()) / 1000 / 60;
    if (diff < 60) {
      return 'green';
    } else {
      return 'red';
    }
  }

  getDeviceLastLocation(device: Device) {
    this.getLastLocationLoading = true;
    this.noLastLocation = false;
    this.deviceService.getDeviceLastLocation(device.deviceId).subscribe((response: any) => {
      if (response.data.latitude === null || response.data.longitude === null) {
        this.noLastLocation = true;
      } else {
        this.map.setView([response.data.latitude, response.data.longitude], 13);
        this.marker?.remove();
        const icon = new Icon.Default();
        icon.options.shadowSize = [0, 0];
        this.marker = marker([response.data.latitude, response.data.longitude], {
          icon
        }).addTo(this.map);
      }

      setTimeout(() => {
        this.map.invalidateSize();
      }, 100);
      this.getLastLocationLoading = false;
    });
  }

  ngAfterViewInit(): void {
    this.dataTable.dtTrigger.next();
    this.map = map('mapid').setView([32.4279, 53.6880], 8);
    const icon = new Icon.Default();
    icon.options.shadowSize = [0, 0];
    this.marker = marker([32.4279, 53.6880], {
      icon
    }).addTo(this.map);
    tileLayer('https://map.radyabs.com/{x}/{y}/{z}/1.png', {maxZoom: 18, attribution: '...'}).addTo(this.map);
  }

  getDeviceList() {
    this.deviceService.getDeviceList().subscribe((devices) => {
      this.devices = devices;
      this.dataTable.rerender(this.dtElement);
      this.loader = false;
    });
  }

  ngOnInit() {
    this.dataTable.dtTrigger = new Subject();
    this.dataTable.dtOptions.order = [[3, 'desc']];
    this.loader = true;
    this.getDeviceList();
    this.role = this.authenticationService.userRole;

  }

  ngOnDestroy(): void {
    this.dataTable.dtTrigger.unsubscribe();
    this.map.clearAllEventListeners();
    this.map.remove();
  }


}
