import {Component, OnDestroy, OnInit} from '@angular/core';
import {DeviceService} from 'src/app/shared/services/device/device.service';
import {ActivatedRoute} from '@angular/router';
import {SubSink} from 'subsink';
import {Device} from 'src/app/shared/models/device.model';
import {User} from 'src/app/shared/models/user.model';
import {DateService} from 'src/app/shared/services/date/date.service';
import {DateModel} from 'src/app/shared/models/date.model';
import moment from 'moment-jalaali';
import {ToastrService} from 'src/app/shared/services/toastr/toastr.service';
import {HttpError} from 'src/app/shared/models/http-error.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-device',
  templateUrl: './edit-device.component.html',
  styleUrls: ['./edit-device.component.scss']
})
export class EditDeviceComponent implements OnInit, OnDestroy {
  sub = new SubSink();
  id: number;
  device: Device;
  users: User[] = [];
  expireAt = {} as DateModel;
  expireAtStr: string;
  minYear = +moment().format('jYYYY');
  phone: string;
  error: any = {};
  addPhoneLoading = false;
  changeExpireAtLoading = false;
  selectedUser: User;
  deletePhoneLoading = false;
  tableLoader = false;

  constructor(
    private deviceService: DeviceService,
    private route: ActivatedRoute,
    private dateService: DateService,
    private toastrService: ToastrService) {
  }

  getDevicePhoneList() {
    this.tableLoader = true;
    this.deviceService.getDevicePhoneLists(this.id).subscribe((response) => {
      this.device = response.device;
      this.users = response.users;
      if (this.device.expireAt) {
        this.expireAt = this.dateService.convertStringDateToDate(this.device.expireAt);
        this.expireAtStr = this.device.expireAt;
      }
      this.tableLoader = false;
    });
  }

  changeExpireAt() {
    this.changeExpireAtLoading = true;
    this.error = {};
    this.deviceService.changeExpireAt(this.device.id, this.expireAtStr).subscribe(() => {
      this.changeExpireAtLoading = false;
      this.toastrService.toastr.success('تاریخ انقضا دستگاه با موفقیت به روزرسانی شد.');
    }, (response) => {
      if (response.status === 422) {
        this.error = response.validationError;
      } else {
        this.toastrService.toastr.error(response.error);
      }
      this.changeExpireAtLoading = false;
    });
  }

  addPhone() {
    this.addPhoneLoading = true;
    this.error = {};
    this.deviceService.addPhone(this.device.id, this.phone).subscribe(() => {
      this.addPhoneLoading = false;
      this.toastrService.toastr.success('شماره‌تلفن با موفقیت به دستگاه اضافه شد.');
      this.device.expireAt = this.expireAtStr;
      this.getDevicePhoneList();
    }, (response) => {
      if (response.status === 422) {
        this.error = response.validationError;
      } else {
        this.toastrService.toastr.error(response.error);
      }
      this.addPhoneLoading = false;
    });
  }

  selectDate(selected: DateModel): void {
    const date = {} as DateModel;
    date.year = selected.year;
    date.month = selected.month;
    date.day = selected.day;
    date.hour = 23;
    date.minute = 59;
    date.second = 59;
    this.expireAtStr = this.dateService.convertDateToString(date);
  }

  deleteUser(user: User) {
    Swal.fire({
      title: 'آیا مطمئن هستید؟',
      icon: 'error',
      text: 'این عملیات قابل بازگشت نمی‌باشد.',
      showCloseButton: false,
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      focusConfirm: false,
      confirmButtonText: 'حذف',
      cancelButtonText: 'انصراف',
    }).then((result) => {
      if (result.value) {
        this.deletePhoneLoading = true;
        this.selectedUser = user;
        this.deviceService.removePhoneFromDevice(this.device.id, user.phone).subscribe(() => {
          this.toastrService.toastr.success('شماره‌تلفن با موفقیت حذف شد.');
          this.deletePhoneLoading = false;
          this.getDevicePhoneList();
        }, (response: HttpError) => {
          if (response.status !== 422) {
            this.toastrService.toastr.error(response.error);
          }
          this.deletePhoneLoading = false;
        });
      }
    });

  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.id = +params.get('id');
      if (this.id) {
        this.getDevicePhoneList();
      }
    });
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
