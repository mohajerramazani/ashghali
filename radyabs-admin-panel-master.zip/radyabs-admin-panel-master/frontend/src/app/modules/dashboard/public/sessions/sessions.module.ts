import {NgModule} from '@angular/core';

import {SessionsRoutingModule} from './sessions-routing.module';
import {SessionsComponent} from './sessions.component';
import {SharedModule} from '../../../../shared/shared.module';
import {DataTablesModule} from 'angular-datatables';


@NgModule({
  declarations: [SessionsComponent],
  imports: [
    SharedModule,
    DataTablesModule,
    SessionsRoutingModule
  ]
})
export class SessionsModule {
}
