import {Component, OnInit, OnDestroy, AfterViewInit, ViewChild} from '@angular/core';
import {LogService} from '../../../../shared/services/log/log.service';
import {DataTableService} from '../../../../shared/data-table/data-table.service';
import {Subject, Subscribable, Subscription} from 'rxjs';
import {Log} from 'src/app/shared/models/log.model';
import {DataTableDirective} from 'angular-datatables';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss']
})
export class LogsComponent implements OnInit, AfterViewInit, OnDestroy {
  logs: Log[] = [];
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  loader = false;
  subscriptions: Subscription[] = [];

  constructor(private logService: LogService, public dataTable: DataTableService) {
  }


  ngAfterViewInit(): void {
    this.dataTable.dtTrigger.next();
  }

  ngOnInit() {
    this.dataTable.dtTrigger = new Subject();
    this.dataTable.dtOptions.order = [[2, 'desc']];
    this.loader = true;

    this.subscriptions.push(
      this.logService.log.subscribe((logs) => {
        this.logs = logs;
        this.dataTable.rerender(this.dtElement);
        this.loader = false;
      }, () => this.loader = false)
    );
  }

  getTime(value) {
    return new Date(value).getTime();
  }

  ngOnDestroy(): void {
    this.dataTable.dtTrigger.unsubscribe();
    this.subscriptions.map(subscription => subscription.unsubscribe());
  }

}
