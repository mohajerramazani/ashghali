import {Component, OnInit} from '@angular/core';
import {UserService} from 'src/app/shared/services/user/user.service';
import {ToastrService} from 'src/app/shared/services/toastr/toastr.service';
import {HttpError} from 'src/app/shared/models/http-error.model';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {
  currentPassword: string;
  error: any = {};
  showCurrentPassword = false;
  showNewPassword = false;
  showConfirmPassword = false;
  confirmPassword: string;
  newPassword: string;
  loading = false;

  constructor(private userService: UserService, private toastrService: ToastrService) {
  }

  changePassword() {
    if (this.newPassword !== this.confirmPassword) {
      this.error = {
        newPassword: ['فیلد گذرواژه و تکرار گذرواژه مطابقت ندارد'],
        confirmPassword: ['فیلد گذرواژه و تکرار گذرواژه مطابقت ندارد'],
      };
      return;
    }
    this.loading = true;
    this.error = {};
    this.userService.changePassword(this.currentPassword, this.newPassword).subscribe((response: any) => {
      this.toastrService.toastr.success(response.message);
      this.loading = false;
    }, (response: HttpError) => {
      if (response.status === 422) {
        this.error = response.validationError;
      } else {
        this.toastrService.toastr.error(response.error);

      }
      this.loading = false;
    });

  }

  getInputType(type: string): string {
    if (type === 'new') {
      if (this.showNewPassword) {
        return 'text';
      }
      return 'password';
    } else if (type === 'confirm') {
      if (this.showConfirmPassword) {
        return 'text';
      }
      return 'password';
    } else {
      if (this.showCurrentPassword) {
        return 'text';
      }
      return 'password';
    }

  }

  toggleShowPassword(type: string): void {
    if (type === 'current') {
      this.showCurrentPassword = !this.showCurrentPassword;
    } else if (type === 'confirm') {
      this.showConfirmPassword = !this.showConfirmPassword;
    } else {
      this.showNewPassword = !this.showNewPassword;
    }
  }

  ngOnInit(): void {
  }

}
