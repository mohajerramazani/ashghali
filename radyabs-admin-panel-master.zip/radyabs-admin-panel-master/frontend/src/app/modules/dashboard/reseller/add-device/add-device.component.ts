import {AfterContentChecked, AfterViewInit, Component, OnInit} from '@angular/core';
import {DeviceService} from '../../../../shared/services/device/device.service';
import {Device} from '../../../../shared/models/device.model';
import {HttpError} from '../../../../shared/models/http-error.model';
import {ToastrService} from '../../../../shared/services/toastr/toastr.service';

@Component({
  selector: 'app-add-device',
  templateUrl: './add-device.component.html',
  styleUrls: ['./add-device.component.scss']
})
export class AddDeviceComponent implements OnInit {
  devices: Device[] = [];
  device = {
    deviceId: '',
    userPhone: ''
  };
  sending = false;
  validationErrors = {};
  message: string;

  constructor(private deviceService: DeviceService, private toastrService: ToastrService) {
  }

  addDevice() {
    this.message = undefined;
    this.validationErrors = {};
    this.sending = true;
    this.deviceService.addDevice(this.device).subscribe((response: any) => {
      if (response.status === 'OK') {
        this.toastrService.toastr.success('دستگاه با موفقیت به کاربر اضافه شد.');
      }
      this.sending = false;
    }, (response: HttpError) => {
      if (response.status === 422) {
        this.validationErrors = response.validationError;
        console.log(this.validationErrors);
      } else if (response.status === 400) {
        this.message = response.error;
      }
      this.sending = false;
    });
  }

  ngOnInit() {
    this.deviceService.getDeviceList().subscribe((devices) => {
      this.devices = devices;
    });
  }

}
