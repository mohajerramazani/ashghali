import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {ResellerRoutingModule} from './reseller-routing.module';
import {AddDeviceComponent} from './add-device/add-device.component';
import {SharedModule} from '../../../shared/shared.module';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [
    AddDeviceComponent
  ],
  imports: [
    SharedModule,
    FormsModule,
    ResellerRoutingModule
  ]
})
export class ResellerModule {
}
