import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {DevicesComponent} from '../public/devices/devices.component';
import {ResellerGuard} from '../../../core/guards/reseller.guard';
import {AddDeviceComponent} from './add-device/add-device.component';


const routes: Routes = [{
  path: '',
  children: [
    {
      path: '',
      redirectTo: 'device/add',
      pathMatch: 'full'
    },
    {
      path: 'device/add',
      component: AddDeviceComponent,
      canActivate: [ResellerGuard]

    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ResellerRoutingModule {
}
