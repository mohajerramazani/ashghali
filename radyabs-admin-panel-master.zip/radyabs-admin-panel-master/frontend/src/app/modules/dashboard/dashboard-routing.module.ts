import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {DashboardComponent} from './dashboard.component';
import {DevicesComponent} from './public/devices/devices.component';
import {AppGuard} from '../../core/guards/app-guard.service';
import {DeviceListGuard} from '../../core/guards/device-list.guard';
import {LogsComponent} from './public/logs/logs.component';
import {ChangePasswordComponent} from 'src/app/modules/dashboard/public/change-password/change-password.component';
import {EditDeviceComponent} from 'src/app/modules/dashboard/public/edit-device/edit-device.component';

const routes: Routes = [{
  path: '',
  component: DashboardComponent,
  canActivate: [AppGuard],
  children: [
    {
      path: '',
      redirectTo: '/devices',
      pathMatch: 'full'
    },
    {
      path: 'devices',
      component: DevicesComponent,
      canActivate: [DeviceListGuard]
    },
    {
      path: 'devices/edit/:id',
      component: EditDeviceComponent,
      canActivate: [DeviceListGuard]
    },
    {
      path: 'change-password',
      component: ChangePasswordComponent,
    },
    {
      path: 'logs',
      component: LogsComponent,
    },
    {
      path: 'active-sessions',
      loadChildren: () => import('./public/sessions/sessions.module').then(m => m.SessionsModule),
    },
    {
      path: 'reseller',
      loadChildren: () => import('./reseller/reseller.module').then(m => m.ResellerModule),
    },
    {
      path: 'reseller-manager',
      loadChildren: () => import('./reseller-manager/reseller-manager.module').then(m => m.ResellerManagerModule),
    },
    {
      path: 'store-keeper',
      loadChildren: () => import('./storekeeper/storekeeper.module').then(m => m.StorekeeperModule),
    },
    {
      path: 'admin',
      loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),
    },
  ]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {
}
