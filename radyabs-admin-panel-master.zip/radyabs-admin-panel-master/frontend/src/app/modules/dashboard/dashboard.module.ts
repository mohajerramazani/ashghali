import {NgModule} from '@angular/core';

import {DashboardRoutingModule} from './dashboard-routing.module';
import {DashboardComponent} from './dashboard.component';
import {SharedModule} from '../../shared/shared.module';
import {DevicesComponent} from './public/devices/devices.component';
import {DataTablesModule} from 'angular-datatables';
import {FormsModule} from '@angular/forms';
import {LogsComponent} from './public/logs/logs.component';
import {LayoutModule} from './layout/layout.module';
import { SystemDetailsComponent } from './admin/system-details/system-details.component';
import {NbFormFieldModule, NbListModule, NbSpinnerModule} from '@nebular/theme';
import { ChangePasswordComponent } from './public/change-password/change-password.component';
import {NgxSkeletonLoaderModule} from 'ngx-skeleton-loader';
import { EditDeviceComponent } from './public/edit-device/edit-device.component';

@NgModule({
  declarations: [
    DashboardComponent,
    DevicesComponent,
    LogsComponent,
    SystemDetailsComponent,
    ChangePasswordComponent,
    EditDeviceComponent,
  ],
    imports: [
        SharedModule,
        DashboardRoutingModule,
        DataTablesModule,
        LayoutModule,
        FormsModule,
        NbListModule,
        NbFormFieldModule,
        NbSpinnerModule,
        NgxSkeletonLoaderModule
    ],
})
export class DashboardModule {
}
